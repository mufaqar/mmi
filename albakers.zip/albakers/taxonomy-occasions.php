<?php get_header();
$tax = $wp_query->get_queried_object();
 
?>
<section>
<div class="page-main-area occasion ">
            <div class="container">
                <div class="row">
                    <div class="col">
                        <div class="main-title"><?php echo $tax->name; ?></div>
                        <div class="breadcrumb-style">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb px-0 bg-transparent m-0">
                                    <li class="breadcrumb-item"><a href="<?php echo home_url(); ?>"><?php _e( 'HOME', 'albaker_ts' ); ?></a></li>
                                    <li class="breadcrumb-item " aria-current="page"><a href="<?php echo home_url(); ?>/albaker-recipes/occasions"><?php _e( 'OCCASIONS', 'albaker_ts' ); ?></a></li>
                                    <li class="breadcrumb-item active" aria-current="page"><?php echo $tax->name; ?></li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- AlBaker World Blog Start Here -->
    <section class="blog-page">
        <!-- Filters Start Here -->
           
      
        <!-- listing Start Here -->
        <div class="blog-grid">
            <div class="container">
                <div class="row">
                <?php if (have_posts()) : while (have_posts()) : the_post();  
                  get_template_part('template-part/recipes','layout');
                     endwhile; endif; ?>
                    
                </div>
            </div>
        </div>
        
    </section>
   <!-- Signup Section Start Here -->
   <?php get_template_part('inc/newletter'); ?>
     <!-- End Signup Section Start Here -->
  
  
<?php get_footer(); ?>


<script type="text/javascript">

$(".tags").on("click", function() {



var prods = $('#tags :selected').val();

$.ajax({
      type:"POST",
      url:"<?php echo admin_url('admin-ajax.php'); ?>",
      data: {
        action: "get_albakers_by_cat",
        cname : prods,		
      },
      success: function(response){
        $( ".nonajax" ).hide();
        $( ".result" ).hide();            
       $( ".load_post" ).html( response );
      }
    });


});

</script>