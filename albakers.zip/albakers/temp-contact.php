<?php  /* Template Name: Contact*/ get_header(); ?>


<section>
        <div class="page-main-area" style="background: url(<?php bloginfo('template_directory'); ?>/images/blur-banner-bar.png) bottom center no-repeat , url(<?php bloginfo('template_directory'); ?>/images/contact-banner.jpg) top center no-repeat;">
            <div class="container">
                <div class="row">
                    <div class="col">
                    <div class="main-title"><?php the_title()?></div>
                        <div class="breadcrumb-style">
                        <?php albakers_breadcrumbs(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- contact Start Here -->
    <section class="contact-page">
        <div class="row">
            <div class="container">
                <!-- block Start Here -->
                <div class="row contact-block">
                    <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
                        <div class="block">
                            <p><strong>EMIRATES GRAIN PRODUCTS COMPANY</strong></br>
                                P.O. BOX 24275,</br>
                                SHARJAH,</br>
                                UNITED ARAB EMIRATES</br>
                                Tel: <a href="tel:+ 971 65286800">+ 971 65286800</a></br>
                                Fax: + 971 6582868</p>
                        </div>
                    </div>
                    <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
                        <div class="block">
                            <p><strong>EMIRATES GRAIN PRODUCTS COMPANY</strong></br>
                                P.O. BOX 24275,</br>
                                SHARJAH,</br>
                                UNITED ARAB EMIRATES</br>
                                Tel: + 971 65286800</br>
                                Fax: + 971 6582868</p>
                        </div>
                    </div>
                    <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
                        <div class="block">
                            <p><strong>EMIRATES GRAIN PRODUCTS COMPANY</strong></br>
                                P.O. BOX 24275,</br>
                                SHARJAH,</br>
                                UNITED ARAB EMIRATES</br>
                                Tel: + 971 65286800</br>
                                Fax: + 971 6582868</p>
                        </div>
                    </div>
                    <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
                        <div class="block">
                            <p><strong>EMIRATES GRAIN PRODUCTS COMPANY</strong></br>
                                P.O. BOX 24275,</br>
                                SHARJAH,</br>
                                UNITED ARAB EMIRATES</br>
                                Tel: + 971 65286800</br>
                                Fax: + 971 6582868</p>
                        </div>
                    </div>
                    <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
                        <div class="block">
                            <p><strong>EMIRATES GRAIN PRODUCTS COMPANY</strong></br>
                                P.O. BOX 24275,</br>
                                SHARJAH,</br>
                                UNITED ARAB EMIRATES</br>
                                Tel: + 971 65286800</br>
                                Fax: + 971 6582868</p>
                        </div>
                    </div>
                    <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
                        <div class="block">
                            <p><strong>INTERNATIONAL AGENCIES COMPANY LTD</strong>
                                </br>
                                BUILDING 406, ROAD 4308,</br>
                                BLOCK 343 MINA SALMAN INDUSTRIAL AREA,</br>
                                BAHRAIN</br>
                                Tel: + 973 17727600</br>
                                Fax: + 973 17728274</br>
                                Mobile: + 973 38898913</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="contact-form">
            <div class="container">
                <div class="row">
                    <div class="col">
                        <div class="main-title text-center">
                            Contact Us
                        </div>
                    </div>
                </div>

                <div class="form-horizontal" >

                <?php echo do_shortcode('[caldera_form id="CF6040b8da7664b"]')?>

                    <div class="row">
                        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
                            <div class="form-group row">
                                <label class="control-label col-xl-3 col-lg-3 col-md-12 col-sm-12 col-12" for="email">Your Name :</label>
                                <div class="col-xl-9 col-lg-9 col-md-12 col-sm-12 col-12">
                                    <input type="text" class="form-control" id="name">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="control-label col-xl-3 col-lg-3 col-md-12 col-sm-12 col-12" for="email">Your Email :</label>
                                <div class="col-xl-9 col-lg-9 col-md-12 col-sm-12 col-12">
                                    <input type="email" class="form-control" id="email">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="control-label col-xl-3 col-lg-3 col-md-12 col-sm-12 col-12" for="email">Country	:</label>
                                <div class="col-xl-9 col-lg-9 col-md-12 col-sm-12 col-12">
                                    <input type="text" class="form-control" id="country">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="control-label col-xl-3 col-lg-3 col-md-12 col-sm-12 col-12" for="email">Zip Code	:</label>
                                <div class="col-xl-9 col-lg-9 col-md-12 col-sm-12 col-12">
                                    <input type="text" class="form-control" id="zip">
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
                            <div class="form-group row feedback">
                                <label class="control-label col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12" for="email">Feedback :</label>
                                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                                    <textarea class="form-control rounded-0" id="textarea" rows="8"></textarea>
                                </div>
                            </div>
                            <div class="form-group row">
                                <div class="col-12">
                                    <button type="submit" class="btn btn-default">SUBMIT FEEDBACK</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>

            </div>
        </div>
    </section>
    <!-- Signup Section Start Here -->
    <?php get_template_part('inc/newletter'); ?>
     <!-- End Signup Section Start Here -->
  
<?php get_footer(); ?>