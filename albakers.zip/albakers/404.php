<?php get_header(); ?>
	
	<section>
        <div class="page-main-area" style="background-image: url('<?php bloginfo('template_directory'); ?>/images/page-banner.jpg');">
            <div class="container">
                <div class="row">
                    <div class="col">
                        <div class="main-title"><?php _e("404 Page Not Found ","albaker_ts"); ?></div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="page-body">
        <div class="container">
            <div class="row">
                <div class="col">
                    <strong><?php _e("Sorry! ... ","albaker_ts"); ?></strong>
                    <p> <?php _e("The page you requested does not exist.","albaker_ts"); ?>
                        </br>
                        <?php _e("Please verify the page title or return to the","albaker_ts"); ?> <a href="<?php echo home_url(); ?>"> <?php _e("home page.","albaker_ts"); ?></a><?php _e("or feel free to browse the recipes below:","albaker_ts"); ?> </p>
                </div>
            </div>
        </div>
    </section>
    <!-- Related Recipes -->
    <div class="related-recipes">
        <div class="container">
            <div class="row">
                <div class="col">
                    <div class="main-title text-center">
                        <?php _e("Recipes","albaker_ts"); ?>
                    </div>
                </div>
            </div>
            <div class="row">
            <?php query_posts(array(
            'post_type' => 'recipes',
            'posts_per_page' => 8,
			'order' => 'desc'
			
        )); 
        if (have_posts()) :  while (have_posts()) : the_post(); 
         get_template_part('template-part/recipes','layout');
         
         endwhile;
         
        // misha_paginator( get_pagenum_link() );
         
        // wp_reset_query(); 
         
         
         else : ?>
			<h2><?php _e('Nothing Found','albaker_ts'); ?></h2>
	        <?php endif; ?>    
                </div>

            </div>
        </div>
    </div>
    <!-- loading more Here -->
  
    <!-- Signup Section Start Here -->
    <?php get_template_part('inc/newletter'); ?>
     <!-- End Signup Section Start Here -->


<?php get_footer(); ?>