<?php get_header(); ?>
<section class="single-recipe-page"  >
   <div class="desktop" id="print">
      <div class="container">
         <div class="row top-area">
            <!-- description area -->
            <div class="col-sm-12 col-md-12 col-lg-6 col-xl-6 col-12">
               <div class="product-detail">
               <div class="product-detail_icon"> </div>

                  <div class="breadcrumb-style p-0">
                            <ol class="breadcrumb px-0 bg-transparent m-0">
                                    <li class="breadcrumb-item"><a href="<?php echo home_url(); ?>"><?php _e( 'HOME', 'albaker_ts' ); ?></a></li>
                                    <li class="breadcrumb-item " aria-current="page"><a href="<?php echo home_url(); ?>/albaker-recipes"><?php _e( 'RECIPES', 'albaker_ts' ); ?></a></li>
                                    <li class="breadcrumb-item active" aria-current="page"><?php the_title(); ?></li>
                                </ol>
                  </div>
                  <div class="product-title">
                     <h2><?php the_title()?></h2>
                  </div>
                  <div class="row">
                     <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12 p-0">
                        <div class="review-area">
                           <?php get_template_part('inc/rating') ?>
                        </div>
                     </div>
                     <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12 p-0">
                        <?php get_template_part('inc/share') ?>
                     </div>
                  </div>
                  <div class="product-description">
                     <?php the_content();?> 
                  </div>
                  <div class="recipe-info">
                     <div class="row">
                        <?php
                           $info = get_field('info');
                           if( $info ):                                  
                           
                           ?>
                        <?php if( $info['prep_time'] ): ?>
                        <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4 col-12">
                           <i class="fa fa-clock-o"></i>
                           <div class="cook-time">
                              <div class="title"><?php _e( 'PREP TIME', 'albaker_ts' ); ?></div>
                              <div class="time"><?php  echo $info['prep_time']; ?></div>
                           </div>
                        </div>
                        <?php endif; ?>            
                        <?php if( $info['bake_time'] ): ?>
                        <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4 col-12">
                           <div class="title"><?php _e( 'BAKE TIME', 'albaker_ts' ); ?></div>
                           <div class="time"><?php  echo $info['bake_time'];  ?></div>
                        </div>
                        <?php endif; ?>  
                        <?php if( $info['total_time'] ): ?>
                        <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4 col-12">
                           <div class="title"><?php _e( 'TOTAL TIME', 'albaker_ts' ); ?></div>
                           <div class="time"><?php echo $info['total_time']; ?></div>
                        </div>
                        <?php endif; ?>  
                     </div>
                     <div class="row mt-4">
                        <?php if( $info['makes'] ): ?>
                        <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4 col-12">
                           <i class="fa fa-user"></i>
                           <div class="cook-time">
                              <div class="title"><?php _e( 'MAKES', 'albaker_ts' ); ?></div>
                              <div class="time"><?php echo $info['makes'];  ?></div>
                           </div>
                        </div>
                        <?php endif; ?>  
                        <div class="col-xl-8 col-lg-8 col-md-8 col-sm-8 col-12">
                           <div class="filter-group" data-filter-group="type">
                              <button class="btn site-btn" onclick="PrintDiv();"><i class="fa fa-plus"></i> <?php _e( 'SAVE RECIPE', 'albaker_ts' ); ?></button>
                              <button class="btn site-btn" onclick="PrintDiv();"><i class="fa fa-print"></i> <?php _e( 'PRINT', 'albaker_ts' ); ?></button>
                           </div>
                        </div>
                     </div>
                     <?php endif; ?>
                  </div>
               </div>
            </div>
            <!-- gallery area-->
            <div class="col-sm-12 col-md-12 col-lg-6 col-xl-6 col-12 ">
               <div class="gallery-carousel">
                  <?php get_template_part('inc/gallery') ?>
                  </div>

            </div>
      </div>
</div>
      <div class="recipe-details" id="divToPrint">
         <div class="recipe-details-area"></div>
         <div class="container">
            <div class="row product-detail ">
               <div class="col-xl-1 col-lg-1 col-md-12 col-sm-12 col-12">
                  <div class="post-share">
                     <?php get_template_part('inc/share-post') ?>
                  </div>
               </div>
               <div class="col-xl-3 col-lg-3 col-md-12 col-sm-12 col-12">
                  <div class="ingredients-info">
                     <h3><?php _e( 'Ingredients', 'albaker_ts' ); ?></h3>
                     <ul>
                        <?php if( have_rows('ingredients') ): ?>
                        <?php while( have_rows('ingredients') ): the_row();                                 
                           $item = get_sub_field('item'); 
                           $heading = get_sub_field('heading'); 
                           ?>
                        <li  class="<?php echo $heading ;?>"  >   <?php echo $item ;?>    </li>
                        <?php endwhile; ?>
                        <?php endif; ?>  
                     </ul>
                  </div>
                  <div class="refer-recipe">
                     <h3><?php _e( 'Perfect for this Recipe', 'albaker_ts' ); ?></h3>
                     <?php
                        $featured_posts = get_field('perfect_for_this_recipe');
                        if( $featured_posts ): ?>
                     <?php foreach( $featured_posts as $post ): 
                        setup_postdata($post); ?>
                     <a href="<?php the_permalink(); ?>">                         
                     <?php if ( has_post_thumbnail() ) {
                        the_post_thumbnail('product-thumbnail');
                        } else { ?>
                     <img src="<?php bloginfo('template_directory'); ?>/images/product-1.jpg" alt="">
                     <?php } ?>
                     <?php the_title(); ?></a>
                     <?php endforeach; ?>
                     <?php 
                        // Reset the global post object so that the rest of the page works correctly.
                        wp_reset_postdata(); ?>
                     <?php endif; ?>
                  </div>
               </div>
               <div class="col-xl-8 col-lg-8 col-md-12 col-sm-12 col-12">
                  <div class="product-description">
                     <h3><?php _e( 'Instructions', 'albaker_ts' ); ?></h3>
                     <?php the_field('instructions'); ?>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
   </div>
   <div class="mobile">
      <div class="container">
         <div class="row top-area">
            <!-- description area -->
            <div class="col-sm-12 col-md-12 col-lg-6 col-xl-6 col-12">
               <div class="product-detail">
                  <div class="breadcrumb-style p-0">
                  <ol class="breadcrumb px-0 bg-transparent m-0">
                                    <li class="breadcrumb-item"><a href="<?php echo home_url(); ?>"><?php _e( 'HOME', 'albaker_ts' ); ?></a></li>
                                    <li class="breadcrumb-item " aria-current="page"><a href="<?php echo home_url(); ?>/albaker-recipes"><?php _e( 'RECIPES', 'albaker_ts' ); ?></a></li>
                                    <li class="breadcrumb-item active" aria-current="page"><?php the_title(); ?></li>
                                </ol>
                  </div>
                  <div class="product-title">
                     <h2><?php the_title()?></h2>
                  </div>
                <div class="gallery-carousel">
                        <?php get_template_part('inc/gallery') ?>
                    </div>
                                    
                  <div class="row">
                     <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12 p-0">
                        <div class="review-area">
                           <?php get_template_part('inc/rating') ?>
                        </div>
                     </div>
                     <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12 p-0">
                        <?php get_template_part('inc/share') ?>
                     </div>
                  </div>
                  <div class="product-description">
                     <?php the_content();?> 
                  </div>
                  <div class="recipe-info">
                     <div class="row">
                        <?php
                           $info = get_field('info');
                           if( $info ): ?>
                        <?php if( $info['prep_time'] ): ?>
                        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
                           <i class="fa fa-clock-o"></i>
                           <div class="cook-time">
                              <div class="title"><?php _e( 'PREP TIME', 'albaker_ts' ); ?></div>
                              <div class="time"><?php  echo $info['prep_time']; ?></div>
                           </div>
                        </div>
                        <?php endif; ?>            
                        <?php if( $info['bake_time'] ): ?>
                        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
                           <div class="title"><?php _e( 'BAKE TIME', 'albaker_ts' ); ?></div>
                           <div class="time"><?php  echo $info['bake_time'];  ?></div>
                        </div>
                        <?php endif; ?>   
                     </div>
                     <div class="row mt-3">
                        <?php if( $info['makes'] ): ?>
                        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
                           <i class="fa fa-user"></i>
                           <div class="cook-time">
                              <div class="title"><?php _e( 'MAKES', 'albaker_ts' ); ?></div>
                              <div class="time"><?php echo $info['makes'];  ?></div>
                           </div>
                        </div>
                        <?php endif; ?>  
                        <?php if( $info['total_time'] ): ?>
                        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
                           <div class="title"><?php _e( 'TOTAL TIME', 'albaker_ts' ); ?></div>
                           <div class="time"><?php echo $info['total_time']; ?></div>
                        </div>
                        <?php endif; ?> 

                     </div>
                     <?php endif; ?>
                  </div>
               </div>
            </div>
            <!-- gallery area-->
            <div class="col-sm-12 col-md-12 col-lg-6 col-xl-6 col-12 ">
               
            </div>
         </div>
      </div>
      <div class="recipe-details" id="divToPrint">
         <div class="container">
            <div class="row product-detail ">
               <div class="col-xl-1 col-lg-1 col-md-12 col-sm-12 col-12">
                  <div class="post-share">
                     <?php get_template_part('inc/share-post') ?>
                  </div>
               </div>
               <div class="col-xl-3 col-lg-3 col-md-12 col-sm-12 col-12">
                  <div class="ingredients-info">
                     <h3><?php _e( 'Ingredients', 'albaker_ts' ); ?></h3>
                     <ul>
                        <?php if( have_rows('ingredients') ): ?>
                        <?php while( have_rows('ingredients') ): the_row();                                 
                           $item = get_sub_field('item'); 
                             $heading = get_sub_field('heading'); 
                           ?>
                        <li  class="<?php echo $heading ;?>"  >   <?php echo $item ;?>    </li>
                        <?php endwhile; ?>
                        <?php endif; ?>  
                     </ul>
                  </div>
                  
               </div>
               <div class="col-xl-8 col-lg-8 col-md-12 col-sm-12 col-12">
                  <div class="product-description">
                     <h3><?php _e( 'Instructions', 'albaker_ts' ); ?></h3>
                     <?php the_field('instructions'); ?>
                  </div>
                  
               </div>
               <div class="refer-recipe">
                     <h3> <?php _e( 'Perfect for this Recipe', 'albaker_ts' ); ?></h3>
                     <?php
                        $featured_posts = get_field('perfect_for_this_recipe');
                        if( $featured_posts ): ?>
                     <?php foreach( $featured_posts as $post ): 
                        setup_postdata($post); ?>
                     <a href="<?php the_permalink(); ?>">                         
                     <?php if ( has_post_thumbnail() ) {
                        the_post_thumbnail('product-thumbnail');
                        } else { ?>
                     <img src="<?php bloginfo('template_directory'); ?>/images/product-1.jpg" alt="">
                     <?php } ?>
                     <?php the_title(); ?></a>
                     <?php endforeach; ?>
                     <?php 
                        // Reset the global post object so that the rest of the page works correctly.
                        wp_reset_postdata(); ?>
                     <?php endif; ?>
                  </div>
            </div>

            <div class="recipe-info">
                <div class="row text-center">
                        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                           <div class="filter-group" data-filter-group="type">
                              <button class="btn site-btn" onclick="PrintDiv();"><i class="fa fa-plus"></i> <?php _e( 'SAVE RECIPE', 'albaker_ts' ); ?></button>
                              <button class="btn site-btn" onclick="PrintDiv();"><i class="fa fa-print"></i> <?php _e( 'PRINT', 'albaker_ts' ); ?></button>
                           </div>
                        </div>
                  </div>
            </div>
         </div>
      </div>
            </div>
   <!-- help section here Here -->
   <div class="help-sec">

   <div class="help-bgsec"></div>
     
      <div class="container">
         <div class="row">
            <div class="col-xl-5 col-lg-5 col-md-5 col-sm-12 col-12">
               <div class="help-logo row">
                  <div class="col-xl-3 col-lg-3 col-md-3 col-sm-3 col-5"> <img src="<?php bloginfo('template_directory'); ?>/images/simple-logo.png" alt=""></div>
                  <div class="col-xl-9 col-lg-9 col-md-9 col-sm-9 col-7 my-auto">
                     <h3><?php _e( 'Do You Need Help?', 'albaker_ts' ); ?></h3>
                  </div>
               </div>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-3 col-sm-12 col-12">
               <div class="list-style-2">
                  <ul>
                     <li><a href="<?php echo home_url(); ?>/albakers/tips-techniques">TIPS & TECHNIQUES</a></li>
                     <li><a href="<?php echo home_url(); ?>/albakers/weight-chart">WEIGHT CHART</a></li>
                     <li><a href="<?php echo home_url(); ?>/albakers/tools-pans">TOOLS & PANS</a></li>
                  </ul>
               </div>
            </div>
            <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12">
               <div class="list-style-2">
                  <ul>
                     <li><a href="<?php echo home_url(); ?>/albakers/measure-flour">MEASURE FLOUR</a></li>
                     <li><a href="<?php echo home_url(); ?>/albakers/safety-instructions">SAFETY INSTRUCTIONS</a></li>
                  </ul>
               </div>
            </div>
         </div>
      </div>
   </div>
</section>
<?php
   get_template_part('temp-related') ?>


<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.3.0/jspdf.umd.min.js"></script>
<script type="text/javascript">     
   function PrintDiv() {    
      var divToPrint = document.getElementById('divToPrint');
      var popupWin = window.open('', '_blank', 'width=1000,height=600');
      popupWin.document.open();
      popupWin.document.write('<html><body onload="window.print()">' + divToPrint.innerHTML + '</html>');
       popupWin.document.close();
           }
</script>
<?php get_footer(); ?>