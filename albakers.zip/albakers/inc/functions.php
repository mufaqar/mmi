<?php


function cptui_register_my_cpts_slides() {

	/**
	 * Post Type: Slides.
	 */

	$labels = [
		"name" => __( "Slides", "twentynineteen" ),
		"singular_name" => __( "Slide", "twentynineteen" ),
	];

	$args = [
		"label" => __( "Slides", "twentynineteen" ),
		"labels" => $labels,
		"description" => "",
		"public" => true,
		"publicly_queryable" => true,
		"show_ui" => true,
		"show_in_rest" => true,
		"rest_base" => "",
		"rest_controller_class" => "WP_REST_Posts_Controller",
		"has_archive" => false,
		"show_in_menu" => true,
		"show_in_nav_menus" => true,
		"delete_with_user" => false,
		"exclude_from_search" => false,
		"capability_type" => "post",
		"map_meta_cap" => true,
		"hierarchical" => false,
		"rewrite" => [ "slug" => "slides", "with_front" => true ],
		"query_var" => true,
		"supports" => [ "title","thumbnail" ],
	];

	register_post_type( "slides", $args );
}

add_action( 'init', 'cptui_register_my_cpts_slides' );


function cptui_register_my_cpts_recipes() {

	/**
	 * Post Type: Recipes.
	 */

	$labels = [
		"name" => __( "Recipes", "twentynineteen" ),
		"singular_name" => __( "Recipe", "twentynineteen" ),
	];

	$args = [
		"label" => __( "Recipes", "twentynineteen" ),
		"labels" => $labels,
		"description" => "",
		"public" => true,
		"publicly_queryable" => true,
		"show_ui" => true,
		"show_in_rest" => true,
		"rest_base" => "",
		"rest_controller_class" => "WP_REST_Posts_Controller",
		"has_archive" => false,
		"show_in_menu" => true,
		"show_in_nav_menus" => true,
		"delete_with_user" => false,
		"exclude_from_search" => false,
		"capability_type" => "post",
		"map_meta_cap" => true,
		"hierarchical" => false,
		"rewrite" => [ "slug" => "recipes", "with_front" => true ],
		"query_var" => true,
		"supports" => [ "title", "editor", "thumbnail","post-formats" ],
	];

	register_post_type( "recipes", $args );
}

add_action( 'init', 'cptui_register_my_cpts_recipes' );


function cptui_register_my_taxes_categories() {

	/**
	 * Taxonomy: Categories.
	 */

	$labels = [
		"name" => __( "Categories", "twentynineteen" ),
		"singular_name" => __( "Category", "twentynineteen" ),
	];

	$args = [
		"label" => __( "Categories", "twentynineteen" ),
		"labels" => $labels,
		"public" => true,
		"publicly_queryable" => true,
		"hierarchical" => true,
		"show_ui" => true,
		"show_in_menu" => true,
		"show_in_nav_menus" => true,
		"query_var" => true,
		"rewrite" => [ 'slug' => 'categories', 'with_front' => true,  'hierarchical' => true, ],
		"show_admin_column" => true,
		"show_in_rest" => true,
		"rest_base" => "categories",
		"rest_controller_class" => "WP_REST_Terms_Controller",
		"show_in_quick_edit" => false,
			];
	register_taxonomy( "categories", [ "recipes" ], $args );
}
add_action( 'init', 'cptui_register_my_taxes_categories' );


function cptui_register_my_taxes_occasions() {

	/**
	 * Taxonomy: Occasions.
	 */

	$labels = [
		"name" => __( "Occasions", "twentynineteen" ),
		"singular_name" => __( "Occasion", "twentynineteen" ),
	];

	$args = [
		"label" => __( "Occasions", "twentynineteen" ),
		"labels" => $labels,
		"public" => true,
		"publicly_queryable" => true,
		"hierarchical" => true,
		"show_ui" => true,
		"show_in_menu" => true,
		"show_in_nav_menus" => true,
		"query_var" => true,
		"rewrite" => [ 'slug' => 'occasions', 'with_front' => true, ],
		"show_admin_column" => true,
		"show_in_rest" => true,
		"rest_base" => "occasions",
		"rest_controller_class" => "WP_REST_Terms_Controller",
		"show_in_quick_edit" => true,
			];
	register_taxonomy( "occasions", [ "recipes" ], $args );
}
add_action( 'init', 'cptui_register_my_taxes_occasions' );


function cptui_register_my_taxes_recipe_tags() {

	/**
	 * Taxonomy: Tags.
	 */

	$labels = [
		"name" => __( "Tags", "twentynineteen" ),
		"singular_name" => __( "Tag", "twentynineteen" ),
	];

	$args = [
		"label" => __( "Tags", "twentynineteen" ),
		"labels" => $labels,
		"public" => true,
		"publicly_queryable" => true,
		"hierarchical" => true,
		"show_ui" => true,
		"show_in_menu" => true,
		"show_in_nav_menus" => true,
		"query_var" => true,
		"rewrite" => [ 'slug' => 'recipe_tags', 'with_front' => true,  'hierarchical' => true, ],
		"show_admin_column" => true,
		"show_in_rest" => true,
		"rest_base" => "recipe_tags",
		"rest_controller_class" => "WP_REST_Terms_Controller",
		"show_in_quick_edit" => true,
			];
	register_taxonomy( "recipe_tags", [ "recipes" ], $args );
}
add_action( 'init', 'cptui_register_my_taxes_recipe_tags' );




function cptui_register_my_cpts_products() {

	/**
	 * Post Type: Products.
	 */

	$labels = [
		"name" => __( "Products", "twentynineteen" ),
		"singular_name" => __( "Product", "twentynineteen" ),
	];

	$args = [
		"label" => __( "Products", "twentynineteen" ),
		"labels" => $labels,
		"description" => "",
		"public" => true,
		"publicly_queryable" => true,
		"show_ui" => true,
		"show_in_rest" => true,
		"rest_base" => "",
		"rest_controller_class" => "WP_REST_Posts_Controller",
		"has_archive" => false,
		"show_in_menu" => true,
		"show_in_nav_menus" => true,
		"delete_with_user" => false,
		"exclude_from_search" => false,
		"capability_type" => "post",
		"map_meta_cap" => true,
		"hierarchical" => false,
		"rewrite" => [ "slug" => "products", "with_front" => true ],
		"query_var" => true,
		"supports" => [ "title", "editor", "thumbnail" ],
	];

	register_post_type( "products", $args );
}

add_action( 'init', 'cptui_register_my_cpts_products' );

function cptui_register_my_taxes_pro_categories() {

	/**
	 * Taxonomy: Categories.
	 */

	$labels = [
		"name" => __( "Categories", "twentynineteen" ),
		"singular_name" => __( "Category", "twentynineteen" ),
	];

	$args = [
		"label" => __( "Categories", "twentynineteen" ),
		"labels" => $labels,
		"public" => true,
		"publicly_queryable" => true,
		"hierarchical" => true,
		"show_ui" => true,
		"show_in_menu" => true,
		"show_in_nav_menus" => true,
		"query_var" => true,
		"rewrite" => [ 'slug' => 'pro_categories', 'with_front' => true, ],
		"show_admin_column" => true,
		"show_in_rest" => true,
		"rest_base" => "pro_categories",
		"rest_controller_class" => "WP_REST_Terms_Controller",
		"show_in_quick_edit" => true,
			];
	register_taxonomy( "pro_categories", [ "products" ], $args );
}
add_action( 'init', 'cptui_register_my_taxes_pro_categories' );




function cptui_register_my_cpts_albakers() {

	/**
	 * Post Type: AlBakers.
	 */

	$labels = [
		"name" => __( "AlBakers", "twentynineteen" ),
		"singular_name" => __( "AlBaker", "twentynineteen" ),
	];

	$args = [
		"label" => __( "AlBakers", "twentynineteen" ),
		"labels" => $labels,
		"description" => "",
		"public" => true,
		"publicly_queryable" => true,
		"show_ui" => true,
		"show_in_rest" => true,
		"rest_base" => "",
		"rest_controller_class" => "WP_REST_Posts_Controller",
		"has_archive" => false,
		"show_in_menu" => true,
		"show_in_nav_menus" => true,
		"delete_with_user" => false,
		"exclude_from_search" => false,
		"capability_type" => "post",
		"map_meta_cap" => true,
		"hierarchical" => false,
		"rewrite" => [ "slug" => "albakers", "with_front" => true ],
		"query_var" => true,
		"supports" => [ "title", "editor", "thumbnail" ],
	];

	register_post_type( "albakers", $args );
}

add_action( 'init', 'cptui_register_my_cpts_albakers' );


function cptui_register_my_taxes_albaker_categories() {

	/**
	 * Taxonomy: Categories.
	 */

	$labels = [
		"name" => __( "Categories", "twentynineteen" ),
		"singular_name" => __( "Category", "twentynineteen" ),
	];

	$args = [
		"label" => __( "Categories", "twentynineteen" ),
		"labels" => $labels,
		"public" => true,
		"publicly_queryable" => true,
		"hierarchical" => true,
		"show_ui" => true,
		"show_in_menu" => true,
		"show_in_nav_menus" => true,
		"query_var" => true,
		"rewrite" => [ 'slug' => 'albaker_categories', 'with_front' => true, ],
		"show_admin_column" => true,
		"show_in_rest" => true,
		"rest_base" => "albaker_categories",
		"rest_controller_class" => "WP_REST_Terms_Controller",
		"show_in_quick_edit" => false,
			];
	register_taxonomy( "albaker_categories", [ "albakers" ], $args );
}
add_action( 'init', 'cptui_register_my_taxes_albaker_categories' );

function cptui_register_my_taxes_albaker_tags() {

	/**
	 * Taxonomy: Tags.
	 */

	$labels = [
		"name" => __( "Tags", "twentynineteen" ),
		"singular_name" => __( "Tag", "twentynineteen" ),
	];

	$args = [
		"label" => __( "Tags", "twentynineteen" ),
		"labels" => $labels,
		"public" => true,
		"publicly_queryable" => true,
		"hierarchical" => true,
		"show_ui" => true,
		"show_in_menu" => true,
		"show_in_nav_menus" => true,
		"query_var" => true,
		"rewrite" => [ 'slug' => 'albaker_tags', 'with_front' => true, ],
		"show_admin_column" => true,
		"show_in_rest" => true,
		"rest_base" => "albaker_tags",
		"rest_controller_class" => "WP_REST_Terms_Controller",
		"show_in_quick_edit" => true,
			];
	register_taxonomy( "albaker_tags", [ "albakers" ], $args );
}
add_action( 'init', 'cptui_register_my_taxes_albaker_tags' );




