<?php get_header(); ?>
<div class="desktop">
   <section class="single-page">
      <div class="container">
         <div class="row top-area">
            <!-- description area -->
            <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12">
            <div class="product-detail">

               <div class="product-detail_icon"> </div>
                  <div class="breadcrumb-style p-0">
                  <ol class="breadcrumb px-0 bg-transparent m-0">
                                    <li class="breadcrumb-item"><a href="<?php echo home_url(); ?>"><?php _e( 'HOME', 'albaker_ts' ); ?></a></li>
                                    <li class="breadcrumb-item " aria-current="page"><a href="<?php echo home_url(); ?>/albaker-world"><?php _e( 'Al Baker World', 'albaker_ts' ); ?></a></li>
                                    <li class="breadcrumb-item active" aria-current="page"><?php the_title(); ?></li>
                                </ol>
                  </div>
                  <div class="product-title">
                     <h2><?php the_title()?> </h2>
                  </div>
                  <div class="row">
                     <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12 p-0">
                        <div class="review-area">
                           <?php get_template_part('inc/rating') ?>
                        </div>
                     </div>
                     <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12 p-0">
                        <?php get_template_part('inc/share') ?>
                     </div>
                  </div>
                  <div class="product-description">
                     <p><?php the_field('description'); ?>   </p>
                  </div>
               </div>
            </div>
            <!-- gallery area-->
            <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12">
               <div class="gallery-carousel">
                  <?php get_template_part('inc/gallery') ?>
               </div>
               <br/><br/>
            </div>
         </div>
         <div class="row product-detail">
            <div class="col-xl-1 col-lg-1 col-md-12 col-sm-12 col-12">
               <div class="post-share">
                  <?php get_template_part('inc/share-post') ?>
               </div>
            </div>
            <div class="col-xl-11 col-lg-11 col-md-12 col-sm-12 col-12">
               <div class="product-description p-0">
                  <?php the_content() ?>
               </div>
            </div>
         </div>
      </div>
   </section>
</div>
<div class="mobile" >
   <section class="single-page">
      <div class="container">
         <div class="row top-area">
            <!-- description area -->
            <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12">
               <div class="product-detail">
                  <div class="breadcrumb-style p-0">
                  <ol class="breadcrumb px-0 bg-transparent m-0">
                                    <li class="breadcrumb-item"><a href="<?php echo home_url(); ?>"><?php _e( 'HOME', 'albaker_ts' ); ?></a></li>
                                    <li class="breadcrumb-item " aria-current="page"><a href="<?php echo home_url(); ?>/albaker-world"><?php _e( 'Al Baker World', 'albaker_ts' ); ?></a></li>
                                    <li class="breadcrumb-item active" aria-current="page"><?php the_title(); ?></li>
                                </ol>
                  </div>
                  <div class="product-title">
                     <h2><?php the_title()?> </h2>
                  </div>
                  <!-- gallery area-->
                  <div class="gallery-carousel">
                  <?php get_template_part('inc/gallery') ?>
                   </div>
                  <div class="row">
                     <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12 p-0">
                        <div class="review-area">
                           <?php get_template_part('inc/rating') ?>
                        </div>
                     </div>
                     <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12 p-0">
                        <?php get_template_part('inc/share') ?>
                     </div>
                  </div>
                  <div class="product-description">
                     <p><?php the_field('description'); ?>   </p>
                  </div>
               </div>
            </div>
            
           
         
         <div class="product-detail">
            <div class="col-xl-1 col-lg-1 col-md-12 col-sm-12 col-12">
               <div class="post-share">
                  <?php get_template_part('inc/share-post') ?>
               </div>
            </div>
            <div class="col-xl-11 col-lg-11 col-md-12 col-sm-12 col-12">
               <div class="product-description ">
                  <?php the_content() ?>
               </div>
            </div>
         </div>
      </div>
   </section>
</div>
<!-- Related Recipes -->
<div class="related-recipes">
 <div class="top-albaker-Collections">
        </div>
   <div class="container">
      <div class="row">
         <div class="col">
            <div class="main-title text-center">
                 <?php _e( 'Al Baker World', 'albaker_ts' ); ?>
            </div>
         </div>
      </div>
      <div class="row blog-grid related_list">
         <?php
            $args = array(
                'post_type' => 'albakers',
                'post_status' => 'publish',
                'posts_per_page' => '-1',
                'paged' => 1,
            );
            $blog_posts = new WP_Query( $args );    ?>
         <?php if ( $blog_posts->have_posts() ) : ?>
         <?php while ( $blog_posts->have_posts() ) : $blog_posts->the_post(); 
            get_template_part('template-part/albaker','layout');
            
            
             endwhile; ?>
         <?php endif; ?>
      </div>
   </div>
</div>

<!-- Signup Section Start Here -->
<?php get_template_part('inc/newletter'); ?>
<?php get_footer(); ?>