<?php  /* Template Name: Albakers */ get_header(); ?>
<section>
        <div class="page-main-area albakers">
            <div class="container">
                <div class="row">
                    <div class="col">
                        <div class="main-title"><?php the_title()?></div>
                        <div class="breadcrumb-style">
                        <?php albakers_breadcrumbs(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- AlBaker World Blog Start Here -->
    <section class="blog-page">
        <!-- Filters Start Here -->
        <div class="filters">
            <div class="container">
                <div class="row">
                   
                    <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6 col-12">
                    <div class="custom-select tags">
                        <?php
                                
                                $tex_recipe_tags = get_terms( array('taxonomy' => 'albaker_categories','hide_empty' => false ) );
                                            
                                            if ( !empty($tex_recipe_tags) ) :
                                                $output = '<select id="tags">';
                                                $output.= '<option hidden >'.__( 'Al Baker Type', 'albaker_ts' ) .'</option>';
                                                foreach( $tex_recipe_tags as $tex_recipe_tag ) {
                                                    $output.= '<option value="'. esc_attr( $tex_recipe_tag->slug ) .'">'. esc_html( $tex_recipe_tag->name ) .'</option>';

                                                }
                                                $output.='</select>';
                                                echo $output;
                                            endif;

                                            ?>
                        </div>
                    </div>
                 
                </div>
            </div>
        </div>
        <!-- Sorting Start Here -->
        <div class="sorting-area">
            <div class="container">
                <div class="row">
                    <div class="col-xl-9 col-lg-8 col-md-7 col-sm-12 col-12 my-auto">
                    <div class="result"> <?php _e( 'We have found', 'albaker_ts' ); ?><?php  $count_articles = wp_count_posts( $post_type = 'recipes' );
                        echo "<span>".$count_articles->publish . "</span>";     ?> <?php _e( 'results fitting your needs', 'albaker_ts' ); ?>
                        </div>
                    </div>
                    <div class="col-xl-3 col-lg-4 col-md-5 col-sm-4 col-12">
                        <div class="custom-select orderfilters">
                            <select id="filters">
                            <option hidden ><?php _e( 'SORT BY ', 'albaker_ts' ); ?></option>
                                 <option value="ASC"><?php _e( 'LATEST ADDED AL BAKER', 'albaker_ts' ); ?></option>
                                <option value="DESC"><?php _e( 'MOST VIEWED AL BAKER', 'albaker_ts' ); ?></option>



                            </select>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- listing Start Here -->
        <div class="blog-grid">
            <div class="container">


            <div class="row load_post">             
                  </div>                                 

                <div class="row nonajax blog-posts posts_list">
                <?php
                    $args = array(
                        'post_type' => 'albakers',
                        'post_status' => 'publish',
                        'posts_per_page' => '-1',
                        'paged' => 1,
                    );
                    $blog_posts = new WP_Query( $args );    ?>

                    <?php if ( $blog_posts->have_posts() ) : ?>
                      
                       
                        <?php while ( $blog_posts->have_posts() ) : $blog_posts->the_post(); 
        
                    get_template_part('template-part/albaker','layout');

                    
                     endwhile; ?>
              <?php endif; ?>
                  
                    
                </div>
            </div>
        </div>
       
    </section>
    <!-- Signup Section Start Here -->
    <?php get_template_part('inc/newletter'); ?>
     <!-- End Signup Section Start Here -->
  



  
<?php get_footer(); ?>

<script type="text/javascript">

var page = 2;
jQuery(function($) {
     
    $('body').on('click', '.loadme', function() {
      
        
        var data = {
            'action': 'load_me_by_ajax',
            'page': page,
            
        };
 
        $.post(ajaxurl, data, function(response) {
            if($.trim(response) != '') {
                $('.blog-posts').append(response);
                page++;
            } else {
                $('.loding-more').hide();
            }
        });
    });

   


});
   



</script>

<script type="text/javascript">

$(".tags").on("click", function() {



var prods = $('#tags :selected').val();

location.href = 'http://demo.mufaqar.com/dev2/albaker_categories/'+prods;



});



$(".orderfilters").on("click", function() {
    
    var filters = $('#filters :selected').val();
   
   jQuery.ajax({
         type:"POST",
         url:"<?php echo admin_url('admin-ajax.php'); ?>",
         data: {
           action: "get_albakers_by_sorting",
           cname : filters,		
         },
         success: function(response){
           $( ".nonajax" ).hide();
           $( ".result" ).hide();            
          $( ".load_post" ).html( response );
         }
       });

});

</script>