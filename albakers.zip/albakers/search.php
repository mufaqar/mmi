<?php get_header(); ?>

<section>
        <div class="page-main-area" style="background: url(<?php bloginfo('template_directory'); ?>/images/blur-banner-bar.png) bottom center no-repeat , url(<?php bloginfo('template_directory'); ?>/images/recipes-banner.jpg) top center no-repeat;">
            <div class="container">
                <div class="row">
                    <div class="col">
                        <div class="main-title">SEARCH RESULTS</div>
                        <div class="breadcrumb-style">
                        <?php albakers_breadcrumbs(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="blog-page">
    <div class="blog-grid">
            <div class="container">

                

        <div class="row load-more-target posts_list">


            <?php if (have_posts()) : ?>
              
                <?php while (have_posts()) : the_post(); 

                    get_template_part('template-part/recipes','layout');


            endwhile; ?>
            <?php if (function_exists("pagination")) {
              //  pagination($additional_loop->max_num_pages);
            } ?>		
            <?php else : ?>
                <h2><?php _e('Nothing Found','text_domain'); ?></h2>
<?php endif; ?>



</div>
        </div>
         
       
    </section>

   <!-- Signup Section Start Here -->
   <?php get_template_part('inc/newletter'); ?>
     <!-- End Signup Section Start Here -->
<?php get_footer(); ?>