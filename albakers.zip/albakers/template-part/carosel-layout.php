<div class="item recipe_filter <?php
                                        $term_obj_list = get_the_terms( $post->ID, 'categories' );
                                        $terms_string = join(', ', wp_list_pluck($term_obj_list, 'name'));
                                        echo $terms_string; ?>">
                            <div class="single-recipe">
                                <a href="<?php the_permalink()?>">
                                    <div class="post-type">                                      
                                          <?php  Albaker_Post_Type(); ?>
                                    </div>
                                <div class="recipe-image">
                                      <?php if ( has_post_thumbnail() ) {
									the_post_thumbnail('full');
								} else { ?>
                                    <img src="<?php bloginfo('template_directory'); ?>/images/default.jpg" alt="">
                                    <?php } ?>

                                 </div>
                                    <div class="single-recipe-body">
                                     <div class="recipe-cat">
                                        <?php
                                        $term_obj_list = get_the_terms( $post->ID, 'categories' );
                                        $terms_string = join(', ', wp_list_pluck($term_obj_list, 'name'));
                                        echo $terms_string; ?>
                                        </div>
                                        <div class="recipe-title"><?php the_title() ; ?></div>
                                        <?php get_template_part('inc/review-widget'); ?>
                                    </div>
                                </a>
                            </div>
                        </div>