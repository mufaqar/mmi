<div class="thumb-sign">
<span class="post-like" >
                            <a data-post_id="<?php echo $post->ID ?>" href="#">        <i class="fa fa-thumbs-o-up" aria-hidden="true"></i>             </a>
</span>
                                    </div>
                                    <div class="review-rating">    

                                    <?php
                                        $likes = get_post_meta($post->ID, "votes_count", true);
                                        $likes = ($likes == "") ? 0 : $likes;
                                    //  echo $likes;
                                        ?>
                                         <span id='like_counter'><?php echo $likes ?> </span> <?php _e( 'REVIEWS', 'albaker_ts' ); ?><br>



                            <span class="post-like <?php if($likes <= "10" ) {  echo "grey-like" ;} ?> " >
                                    <a data-post_id="<?php echo $post->ID ?>" href="#">
                                    
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            
                                    </a>
                            </span>
  
               </div>
                                    <div class="clear"></div>

