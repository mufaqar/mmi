<?php /* Template Name: Testing */ get_header(); ?>
	




    <!-- Recipe Collections Start Here -->
    <section class="Recipe-Collections">
        <div class="top-Recipe-Collections">
        </div>
        <div class="main-Recipe-Collections">
            <div class="container">
                <div class="row">
                    <div class="col-xl-3 col-lg-12 col-md-12 col-sm-12 col-12">
                        <div class="main-title">
                             <?php _e( 'Recipe Collections', 'albaker_ts' ); ?>
                        </div>
                    </div>


                    <div class="col-xl-9 col-lg-12 col-md-12 col-sm-12 col-12 mt-auto">
                        <div class="filter-btn">
                            <div class="filter-group" id="myBtnContainer">
                                <button class="btn site-btn ajaxbtn"  data-id="dessert">Dessert</button>
                                <button class="btn site-btn ajaxbtn"  data-id="appetizer">Appetizer</button>
                                <button class="btn site-btn ajaxbtn"  data-id="savory" >Savory</button>
                                <button class="btn site-btn active">DISCOVER ALL</button>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row load_post">

                

                

             <div id="Recipes-owl-carousel" class="nonajax owl-carousel grid" >
                                <?php query_posts(array(
                                'post_type' => 'recipes',
                                'posts_per_page' => 6,
                                'order' => 'desc'
                                
                            )); 
                            if (have_posts()) :  while (have_posts()) : the_post();         
                                    get_template_part('template-part/homerecipes','layout');
                                endwhile; wp_reset_query(); else : ?>
                                <h2><?php _e('Nothing Found','albaker_ts'); ?></h2>
                                <?php endif; ?>          
                                        
                      </div>




              


                      

                 </div>
            </div>
        </div>
    </section>







   


<?php get_footer(); ?>

<script>
$(document).ready(function(){
  $(".ajaxbtn").click(function(){



    var prods = $(this).attr("data-id"); 
    alert(prods);
   
   jQuery.ajax({
         type:"POST",
         url:"<?php echo admin_url('admin-ajax.php'); ?>",
         data: {
           action: "get_carosel",
           cname : prods,		
         },
         success: function(response){
           $( ".nonajax" ).hide();
                  
          $( ".load_post" ).html( response );
          var owl = $("#ajax-carosel");
            owl.owlCarousel({
                loop: true,
                margin: 10,
                nav: true,
                autoPlay: 3000,
                items: 4, // THIS IS IMPORTANT
                responsive: {
                    480: {
                        items: 1
                    }, // from zero to 480 screen width 1 items
                    768: {
                        items: 2
                    }, // from 480 screen widthto 768 2 items
                    1024: {
                        items: 3
                    }, // from 768 screen width to 1024 3 items
                    1200: {
                        items: 3
                    }, // from 768 screen width to 1024 4 items
                    1920: {
                        items: 4
                    } // from 768 screen width to 1024 5 items

                }
            });
         }
       });
  });
});
</script>










<script type="text/javascript">
        //Recipe-Collections
        $(document).ready(function() {
            $('#Recipes-owl-carousel').owlCarousel({
                loop: true,
                margin: 10,
                nav: true,
                autoPlay: 3000,
                items: 4, // THIS IS IMPORTANT
                responsive: {
                    480: {
                        items: 1
                    }, // from zero to 480 screen width 1 items
                    768: {
                        items: 2
                    }, // from 480 screen widthto 768 2 items
                    1024: {
                        items: 3
                    }, // from 768 screen width to 1024 3 items
                    1200: {
                        items: 3
                    }, // from 768 screen width to 1024 4 items
                    1920: {
                        items: 4
                    } // from 768 screen width to 1024 5 items

                }
            })
        });
        // products-carousel
        $(document).ready(function() {
            $('#products-owl-carousel').owlCarousel({
                loop: true,
                margin: 10,
                nav: true,
                autoPlay: 3000,
                items: 6, // THIS IS IMPORTANT
                responsive: {
                    480: {
                        items: 1
                    }, // from zero to 480 screen width 1 items
                    768: {
                        items: 2
                    }, // from 480 screen widthto 768 2 items
                    1024: {
                        items: 3
                    }, // from 768 screen width to 1024 3 items
                    1200: {
                        items: 5
                    }, // from 768 screen width to 1024 4 items
                    1920: {
                        items: 6
                    } // from 768 screen width to 1024 5 items

                }
            })
        });


$(document).ready(function(){
    alert("asdfa")

    $("#test").click(function(){

alert("Test");

   
 

});

</script>