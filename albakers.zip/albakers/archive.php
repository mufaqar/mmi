<?php get_header();?>	

<section>
        <div class="page-main-area" style="background-image: url(<?php bloginfo('template_directory'); ?>/images/world-banner.jpg);">
            <div class="container">
                <div class="row">
                    <div class="col">
                        <div class="main-title"><?php echo get_the_archive_title() ?></div>
                        <div class="breadcrumb-style">
                        <?php //albakers_breadcrumbs(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- AlBaker World Blog Start Here -->

<section class="News blog-grid">
        <div class="container">
            <div class="row">
                <div class="col">
                    <div class="main-title text-center mb-4">
                 
                 


<?php if (have_posts()) : ?>
<?php $post = $posts[0]; // Hack. Set $post so that the_date() works. ?>
<?php /* If this is a category archive */ if (is_category()) { ?>
	<h2><?php _e('Archive for the','text_domain'); ?> &#8216; <?php single_cat_title(); ?> &#8217; <?php _e('Category','text_domain'); ?></h2>
<?php /* If this is a tag archive */ } elseif( is_tag() ) { ?>
	<h2><?php _e('Posts Tagged', 'text_domain'); ?> &#8216; <?php single_tag_title(); ?> &#8217;</h2>
<?php /* If this is a daily archive */ } elseif (is_day()) { ?>
	<h2><?php _e('Archive for','text_domain'); ?> <?php the_time('F jS, Y'); ?></h2>
<?php /* If this is a monthly archive */ } elseif (is_month()) { ?>
	<h2><?php _e('Archive for','text_domain'); ?> <?php the_time('F, Y'); ?></h2>
<?php /* If this is a yearly archive */ } elseif (is_year()) { ?>
	<h2><?php _e('Archive for','text_domain'); ?> <?php the_time('Y'); ?></h2>
<?php /* If this is an author archive */ } elseif (is_author()) { ?>
	<h2><?php _e('Author Archive','text_domain'); ?> </h2>
<?php /* If this is a paged archive */ } elseif (isset($_GET['paged']) && !empty($_GET['paged'])) { ?>
	<h2><?php _e('Blog Archives','text_domain'); ?> </h2>
<?php } ?>

</div>
                </div>
            </div>
            <div class="row">
<?php while (have_posts()) : the_post(); ?>
<div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12">
                    <div class="single-blog">
                        <a href="<?php the_permalink()?>">
                            <div class="post-type"></div>
                            <div class="blog-image">
                               <?php if ( has_post_thumbnail() ) {
									the_post_thumbnail('blog-thumbnail');
								} else { ?>
						  <img src="<?php bloginfo('template_directory'); ?>/images/news-1.jpg">
							<?php } ?>

                            </div>
                            <div class="single-blog-body">
                                <div class="blog-title"><?php the_title()?></div>
                            </div>
                        </a>
                    </div>
                </div>
<?php endwhile; ?>
<?php if (function_exists("pagination")) {
	//pagination($additional_loop->max_num_pages);
} ?>			
<?php else : ?>
	<h2><?php _e('Nothing Found','text_domain'); ?></h2>
<?php endif; ?>
</div>
</div>
</section>

<?php get_footer(); ?>