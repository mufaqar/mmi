<?php get_header(); ?>


<section>
        <div class="page-main-area" style="background: url(<?php bloginfo('template_directory'); ?>/images/blur-banner-bar.png) bottom center no-repeat , url(<?php bloginfo('template_directory'); ?>/images/contact-banner.jpg) top center no-repeat;">
            <div class="container">
                <div class="row">
                    <div class="col">
                        <div class="main-title"><?php the_title()?></div>
                        <div class="breadcrumb-style">
                        <?php albakers_breadcrumbs(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="about-page">
        <div class="container">
            <div class="block">
                <div class="row">
                    <div class="col">
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
    <div <?php post_class() ?> id="post-<?php the_ID(); ?>">
    

    	<h2><?php the_title(); ?></h2>
        <?php //include (TEMPLATEPATH . '/inc/meta.php' ); ?>	
		<div class="entry">
           <?php if ( has_post_thumbnail() ) { ?>
    		    <div class="featured-image">
			<?php //the_post_thumbnail( 'single-post-thumbnail' ); ?>
    		    </div>
			<?php } ?>		
			<?php the_content(); ?>
            <?php wp_link_pages(array('before' => 'Pages: ', 'next_or_number' => 'number')); ?>
            
        </div>
    </div>
	<?php edit_post_link(__('Edit','text_domain'),'','.'); ?>
	<?php //comments_template(); ?>
<?php endwhile; endif; ?>
</div>
</section>     </div>
                </div>
            </div>
        
        </div>
    </section>

     <!-- Signup Section Start Here -->
     <?php get_template_part('inc/newletter'); ?>
     <!-- End Signup Section Start Here -->

<?php get_footer(); ?>