<div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
                        <div class="single-blog">
                            <a href="<?php the_permalink()?>">
                                <div class="post-type">
                                <?php  Albaker_Post_Type(); ?>
                                </div>
                                <div class="blog-image">
                                    <?php if ( has_post_thumbnail() ) {
									the_post_thumbnail('bakers-thumbnail');
								} else { ?>
							     <img src="<?php bloginfo('template_directory'); ?>/images/blog-1.jpg">
							<?php } ?>

                                </div>
                                <div class="single-blog-body">
                                    <div class="bolg-cat">
                                    <?php
                                        $term_bakers_list = get_the_terms( $post->ID, 'albaker_categories' );
                                        $terms_bakers = join(', ', wp_list_pluck($term_bakers_list, 'name'));
                                        echo $terms_bakers;
                                        ?>

                                    </div>
                                    <div class="blog-title"><?php the_title()?></div>
                                </div>
                            </a>
                        </div>
                    </div>