<?php  /* Template Name: About */ get_header(); ?>

<section>
        <div class="page-main-area" style="background: url(<?php bloginfo('template_directory'); ?>/images/blur-banner-bar.png) bottom center no-repeat , url(<?php bloginfo('template_directory'); ?>/images/about-banner.jpg) top center no-repeat;">
            <div class="container">
                <div class="row">
                    <div class="col">
                    <div class="main-title"><?php the_title()?></div>
                        <div class="breadcrumb-style">
                        <?php albakers_breadcrumbs(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- about Start Here -->
    <section class="about-page">
        <div class="container">
            <div class="block">
                <div class="row">
                    <div class="col">
                        <h2>Company’s Profile</h2>
                        <p><strong>Emirates Grain Products Company</br> Traditional. Modern. Futuristic - All at Once.</strong></br>
                            </br>Emirates Grain Product Company, popularly known as Emigrain, was incepted in 1995 with a vision to provide the world with the finest range of essential and value-added flour. In less than a decade, Emigrain has grown to become
                            a leading manufacturer and marketer of wheat-based products in the Middle East. Powered by in-depth knowledge of food industry and backed by state-of-the-art HACCP-certified mills, Emigrain today epitomizes the best in product
                            innovation and quality standards. With a daily production output that exceeds 1800 tons. An immensely popular product from the stable of Emigrain, Al Baker reflects its parent company’s unflinching commitment to ensure stringent
                            quality control measures from sourcing the finest raw materials to sealing the freshness in tamper-proof packs.</p>
                    </div>
                </div>
            </div>
            <div class="block">
                <div class="row">
                    <div class="col">
                        <h2>Company’s Vision</h2>
                        <p><strong>To be a leading flour company within the chosen segments in GCC by providing quality products, superior customer focus and innovations.</strong>
                        </p>
                    </div>
                </div>
            </div>
            <div class="block">
                <div class="row">
                    <div class="col-xl-8 col-lg-8 col-md-8 col-sm-12 col-12">
                        <h2>Company’s Values</h2>
                        <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going to use
                            a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first
                            true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always
                            free from repetition, injected humour, or non-characteristic words etc.</p>
                    </div>
                    <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12">
                        <div>
                            <img src="<?php bloginfo('template_directory'); ?>/images/Company-Values.png" class="w-100">
                        </div>
                    </div>
                </div>
            </div>
            <div class="block">
                <div class="row">
                    <div class="col">
                        <h2>Fresh Ingredients Make Fine Products</h2>
                        <p>At Emigran, we live by this work philosophy and handpick only the choicest wheat grains from the world’s finest fields. Carefully sourced wheat grains are subject to multi-level cleaning process to ensure total hygiene. Once flawlessly
                            cleaned, the grains are milled in state-of-the-art factories and freshly sealed in a tamper-proof packs completely untouched by hand.</p>
                    </div>
                </div>
            </div>
            <div class="block">
                <div class="row">
                    <div class="col">
                        <h2>Hygienically Processed</h2>
                        <p>In the light of growing conssumer consciousness as well as regionalization and globalization, we at Emigrain, under trained staff and Certified Quality Professional, make sure that our end product is processed best and are untouched
                            by human hands during its processing before it reaches our consumers.</p>
                        <p>
                            <b>Quality</b>
                            <ul>
                                <li>Corporate Quality system covered under FD 22000 certification.</li>
                                <li> Metals & Glass policies in place and implemented.</li>
                                <li>3rd party inspection and quality audits regularly carried out and encouraged. </li>
                                <li>Follow USFDA, USDA & COOL Guidlines.</li>
                            </ul>
                        </p>
                    </div>
                </div>
                <div class="row about-logos">
                    <div class="col-xl-4 col-lg-4 col-md-4 col-sm-6 col-12">
                        <img src="<?php bloginfo('template_directory'); ?>/images/about-logo-1.png" alt="" class="w-100">
                    </div>
                    <div class="col-xl-4 col-lg-4 col-md-4 col-sm-6 col-12">
                        <img src="<?php bloginfo('template_directory'); ?>/images/about-logo-2.png" alt="" class="w-100">
                    </div>
                    <div class="col-xl-4 col-lg-4 col-md-4 col-sm-6 col-12">
                        <img src="<?php bloginfo('template_directory'); ?>/images/about-logo-3.png" alt="" class="w-100">
                    </div>
                </div>
            </div>
        </div>
    </section>
     <!-- Signup Section Start Here -->
     <?php get_template_part('inc/newletter'); ?>
     <!-- End Signup Section Start Here -->
  
  
<?php get_footer(); ?>