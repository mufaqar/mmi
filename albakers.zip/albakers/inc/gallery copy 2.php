<!-- Carousel -->
<div id="carousel-example" class="carousel slide">
	       					
	       					<div class="carousel-inner">
	       						
                                   
                                   
                               <div class="carousel-item active">
	       							<div class="zoom">
	       							<img src="<?php bloginfo('template_directory'); ?>/images/galery-6.jpg"  />
	       							</div>
	       						</div>
                                   
                                   <div class="carousel-item ">
	       							<div class="embed-responsive embed-responsive-16by9">
	       								<iframe class="embed-responsive-item" src="https://www.youtube.com/embed/6hgVihWjK2c?rel=0" allowfullscreen></iframe>
	       							</div>
	       						</div>

	       						
								<div class="carousel-item">
	       							<div class="zoom">
	       								<img src="<?php bloginfo('template_directory'); ?>/images/galery-6.jpg" />
	       							</div>
	       						</div>
								
								<div class="carousel-item">
	       							<div class="embed-responsive embed-responsive-16by9">
	       								<iframe class="embed-responsive-item" src="https://player.vimeo.com/video/84910153?title=0&amp;byline=0&amp;portrait=0&amp;badge=0&amp;color=ffffff" allowfullscreen></iframe>
	       							</div>
	       						</div>
								
								
								
	       						<div class="carousel-item">
	       							<div class="embed-responsive embed-responsive-16by9">
	       								<iframe class="embed-responsive-item" src="https://www.youtube.com/embed/oiKj0Z_Xnjc" allowfullscreen></iframe>
	       							</div>
	       						</div>
	       					</div>


							<a class="carousel-control-prev" href="#carousel-example" role="button" data-slide="prev">
								<span class="carousel-control-prev-icon" aria-hidden="true"></span>
								<span class="sr-only">Previous</span>
							</a>
							<a class="carousel-control-next" href="#carousel-example" role="button" data-slide="next">
								<span class="carousel-control-next-icon" aria-hidden="true"></span>
								<span class="sr-only">Next</span>
							</a>

                            <ol class="carousel-indicators">
	       						<li data-target="#carousel-example" data-slide-to="0" class="active"></li>
	       						<li data-target="#carousel-example" data-slide-to="1"></li>
									<li data-target="#carousel-example" data-slide-to="2"></li>
										<li data-target="#carousel-example" data-slide-to="3"></li>
	       						<li data-target="#carousel-example" data-slide-to="4"></li>
	       					</ol>


                               <div id="carousel-thumbs" class="carousel carousel-thumbs">
                            <div class="carousel-inner">
                                <div class="carousel-item active">
                                    <div class="carousel-thumbs-row">
                                        <div class="thumb  selected" data-target="#myCarousel" data-slide-to="0">
                                            <img src="images/galery-1.jpg" class="img-fluid">
                                        </div>
                                        <div class="thumb" data-target="#myCarousel" data-slide-to="1">
                                            <img src="images/galery-2.jpg" class="img-fluid">
                                        </div>
                                        <div class="thumb" data-target="#myCarousel" data-slide-to="2">
                                            <img src="images/galery-3.jpg" class="img-fluid">
                                        </div>

                                    </div>
                                </div>
                                <div class="carousel-item">
                                    <div class="carousel-thumbs-row">
                                        <div class="thumb" data-target="#myCarousel" data-slide-to="3">
                                            <img src="images/galery-4.jpg" class="img-fluid">
                                        </div>
                                        <div class="thumb" data-target="#myCarousel" data-slide-to="4">
                                            <img src="images/galery-5.jpg" class="img-fluid">
                                        </div>
                                        <div class="thumb" data-target="#myCarousel" data-slide-to="5">
                                            <img src="images/galery-6.jpg" class="img-fluid">
                                        </div>

                                    </div>
                                </div>
                                <a class="carousel-control-prev" href="#carousel-thumbs" role="button" data-slide="prev">
                                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                    <span class="sr-only">Previous</span>
                                </a>
                                <a class="carousel-control-next" href="#carousel-thumbs" role="button" data-slide="next">
                                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                    <span class="sr-only">Next</span>
                                </a>
                            </div>

                        </div>






	       				</div>
	                	<!-- End carousel -->
        
    
    