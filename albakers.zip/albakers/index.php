<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package WordPress
 * @subpackage Twenty_Seventeen
 * @since 1.0
 * @version 1.0
 */

get_header(); ?>

<div class="blog-grid">
        <div class="container">

<div class='row posts_list'>

<?php query_posts(array(
            'post_type' => 'recipes',
            'posts_per_page' => -1,
			'order' => 'desc'
			
        )); 
        if (have_posts()) :  while (have_posts()) : the_post(); 

        get_template_part('template-part/recipes','layout');
    
endwhile; wp_reset_query(); 
 
 
 else : ?>
    <h2><?php _e('Nothing Found','textdomain'); ?></h2>
    <?php endif; ?>    
        </div>
      </div>

      
     
   








<?php get_footer(); ?>

