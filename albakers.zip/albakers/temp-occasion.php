<?php  /* Template Name: Occasion */ get_header(); ?>

<section>
        <div class="page-main-area occasion ">
            <div class="container">
                <div class="row">
                    <div class="col">
                        <div class="main-title"><?php the_title()?></div>
                        <div class="breadcrumb-style">
                        <?php albakers_breadcrumbs(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- AlBaker World Blog Start Here -->
    <section class="occasions-page">
        <!-- product listing Start Here -->
        <div class="product-grid pt-0">
            <div class="container">
                <div class="row">
                    <div class="col-xl-8 col-lg-8 col-md-6 col-sm-12 col-12">
                        <div class="single-product">
                            <div class="product-image">
                                <a href="<?php echo home_url('/occasions/eid'); ?>"><img src="<?php bloginfo('template_directory'); ?>/images/occasions-1.jpg"></a>
                            </div>
                            <div class="single-product-body">
                                <a href="<?php echo home_url('/occasions/eid'); ?>">
                                    <div class="product-title"> <?php _e( 'Eid', 'albaker_ts' ); ?> </div>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 col-12">
                        <div class="single-product">
                            <div class="product-image">
                                <a href="<?php echo home_url('/occasions/ramadan'); ?>"><img src="<?php bloginfo('template_directory'); ?>/images/occasions-2.jpg"></a>
                            </div>
                            <div class="single-product-body">
                                <a href="<?php echo home_url('/occasions/ramadan'); ?>">
                                    <div class="product-title"> <?php _e( 'Ramadan', 'albaker_ts' ); ?> </div>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 col-12">
                        <div class="single-product">
                            <div class="product-image">
                                <a href="<?php echo home_url('/occasions/birthdays'); ?>"><img src="<?php bloginfo('template_directory'); ?>/images/occasions-3.jpg"></a>
                            </div>
                            <div class="single-product-body">
                                <a href="<?php echo home_url('/occasions/birthdays'); ?>">
                                    <div class="product-title"><?php _e( 'Birthdays', 'albaker_ts' ); ?> </div>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 col-12">
                        <div class="single-product">
                            <div class="product-image">
                                <a href="<?php echo home_url('/occasions/holidays'); ?>"><img src="<?php bloginfo('template_directory'); ?>/images/occasions-4.jpg"></a>
                            </div>
                            <div class="single-product-body">
                                <a href="<?php echo home_url('/occasions/holidays'); ?>">
                                    <div class="product-title"><?php _e( 'Holidays', 'albaker_ts' ); ?></div>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 col-12">
                        <div class="single-product">
                            <div class="product-image">
                                <a href="<?php echo home_url('/occasions/diwali'); ?>"><img src="<?php bloginfo('template_directory'); ?>/images/occasions-5.jpg"></a>
                            </div>
                            <div class="single-product-body">
                                <a href="<?php echo home_url('/occasions/diwali'); ?>">
                                    <div class="product-title"><?php _e( 'Diwali', 'albaker_ts' ); ?></div>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        </div>
    </section>
    <!-- Signup Section Start Here -->
    
   
  
<?php get_footer(); ?>