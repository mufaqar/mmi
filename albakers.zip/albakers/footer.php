 <!-- Footer Start Here -->
 <footer class="footer">
        <!-- Main Footer Start Here -->
        <div class="main-footer">
            <div class="container">
                <div class="footer-container">
                    <div class="row">
                        <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6 col-12">
                            <div class="footer-widget">
                                <h5><?php _e( 'AL BAKER WORLD', 'albaker_ts' ); ?></h5>
                                <nav class="navbar bg-transparent p-0">
                                  <?php wp_nav_menu( array( 'theme_location' => 'footer-albaker','menu_class'=> 'navbar-nav','container' => 'false' ) ); ?>
                                </nav>
                                <h5><?php _e( 'ABOUT US', 'albaker_ts' ); ?></h5>
                                <nav class="navbar bg-transparent p-0">
                                <?php wp_nav_menu( array( 'theme_location' => 'footer-about','menu_class'=> 'navbar-nav','container' => 'false' ) ); ?>
                                </nav>

                            </div>
                        </div>
                        <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6 col-12">
                            <div class="footer-widget">
                                <h5> <?php _e( 'RECIPES', 'albaker_ts' ); ?></h5>
                                <nav class="navbar bg-transparent p-0">
                                <?php wp_nav_menu( array( 'theme_location' => 'footer-recipes','menu_class'=> 'navbar-nav','container' => 'false' ) ); ?>
                                </nav>

                            </div>
                        </div>
                        <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6 col-12">
                            <div class="footer-widget">
                                <h5><?php _e( 'OUR PRODUCTS', 'albaker_ts' ); ?> </h5>
                                <nav class="navbar bg-transparent p-0">
                                <?php wp_nav_menu( array( 'theme_location' => 'footer-products','menu_class'=> 'navbar-nav','container' => 'false' ) ); ?>
                                </nav>

                            </div>
                        </div>
                        <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6 col-12">
                            <div class="footer-widget">
                                <h5> <?php _e( 'FOLLOW US', 'albaker_ts' ); ?> </h5>
                                <div class="social-links">
                                    <nav class="navbar navbar-expand-sm navbar bg-transparent p-0">
                                        <ul class="navbar-nav">
                                            <li class="nav-item">
                                                <a class="nav-link" href="https://www.facebook.com/iffco.albaker/" target="_blank"><i class="fa fa-facebook-f"></i></a>
                                            </li>
                                            <li class="nav-item">
                                                <a class="nav-link" href="https://twitter.com/iffcoalbaker" target="_blank"><i class="fa fa-twitter"></i></a>
                                            </li>
                                            <li class="nav-item">
                                                <a class="nav-link" href="https://www.youtube.com/user/IffcoAlBaker" target="_blank"><i class="fa fa-youtube" target="_blank"></i></a>
                                            </li>
                                            <li class="nav-item">
                                                <a class="nav-link" href="https://www.pinterest.com/al_baker.iffco/" target="_blank"><i class="fa fa-pinterest" target="_blank"></i></a>
                                            </li>
                                            <li class="nav-item">
                                                <a class="nav-link" href="https://www.instagram.com/al_baker.iffco" target="_blank"><i class="fa fa-instagram"></i></a>
                                            </li>


                                        </ul>
                                    </nav>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Copywrite Footer Start Here -->
        <div class="copywrite-footer">
            <div class="container">
                <div class="row">
                    <div class="col">
                        <p><?php _e( '© 2021 AlBaker— All rights reserved', 'albaker_ts' ); ?> </p>
                    </div>
                </div>
            </div>
        </div>
    </footer>

    <div class="overlay"></div>
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="<?php bloginfo('template_directory'); ?>/js/jquery-3.5.1.js"></script>
    <script src="<?php bloginfo('template_directory'); ?>/js/popper.min.js"></script>
    <script src="<?php bloginfo('template_directory'); ?>/js/bootstrap.min.js"></script>
   <!-- <script src="<?php bloginfo('template_directory'); ?>/js/jqueryslim.min.js"></script> -->
    <script src="<?php bloginfo('template_directory'); ?>/js/owl.carousel.js"></script>
    
    
    
   
    <script src="<?php bloginfo('template_directory'); ?>/js/jquery.simpleLoadMore.js"></script>

    <link href="<?php bloginfo('template_directory'); ?>/test/lightzoom-master/glassstyle.css" rel="stylesheet">
  
  <script src="<?php bloginfo('template_directory'); ?>/test/lightzoom-master/lightzoom.js"></script>



<script>


if ($(window).width() > 992) {
  $(window).scroll(function(){  
     if ($(this).scrollTop() > 40) {
        $('#header-desktop').addClass("fixed-top");
        $('#header-desktop').css('position', 'fixed');

        // add padding top to show content behind navbar
        $('body').css('padding-top', $('.navbar').outerHeight() + 'px');
      }else{
        $('#header-desktop').removeClass("fixed-top");
         // remove padding top from body
        $('body').css('padding-top', '0');
        $('#header-desktop').css('position', 'relative');
      }   
  });
} // end if

$(".zoom-in").click(function(){

   
   $( ".zoomit" ).addClass( "light-zoom" );
   $('img.light-zoom').lightzoom({
            zoomPower   : 2,    //Default
            glassSize   : 300,  //Default
        });


    
});

$(".zoom-out").click(function(){

    

    $( ".zoomit" ).removeClass( "light-zoom" );

    $( "#glass" ).css("display", "none !important");
    $("#glass").remove();
    
       
    
   
});


$(document).on({
    ajaxStart: function(){
        $("body").addClass("loading"); 
    },
    ajaxStop: function(){ 
        $("body").removeClass("loading"); 
    }    
});



window.onscroll = function(ev) {
    if ((window.innerHeight + window.scrollY) >= document.body.offsetHeight) {
        
      //  $( ".loding-more" ).click();
    }
};





function loadMore()
{
   console.log("More loaded");
   $( ".loding-more" ).click();
   $(window).bind('scroll', bindScroll);
 }

 function bindScroll(){
   if($(window).scrollTop() + $(window).height() > $(document).height() - 350) {
       $(window).unbind('scroll');
       loadMore();
   }
}

$(window).scroll(bindScroll);


</script>





    <style>
    
    /* Shrink wrap strategy 1 */
.easyzoom {
    float: left;
}
.easyzoom img {
    display: block;
}


/* Shrink wrap strategy 2 */
.easyzoom {
    display: inline-block;
}
.easyzoom img {
    vertical-align: bottom;
}
    
    </style>

   
<script type="text/javascript">
        //Recipe-Collections
        $(document).ready(function() {
            $('#Recipes-owl-carousel').owlCarousel({
                loop: true,
                margin: 10,
                nav: true,
                autoPlay: 3000,
                items: 4, // THIS IS IMPORTANT
                responsive: {
                    480: {
                        items: 1
                    }, // from zero to 480 screen width 1 items
                    768: {
                        items: 2
                    }, // from 480 screen widthto 768 2 items
                    1024: {
                        items: 3
                    }, // from 768 screen width to 1024 3 items
                    1200: {
                        items: 3
                    }, // from 768 screen width to 1024 4 items
                    1920: {
                        items: 4
                    } // from 768 screen width to 1024 5 items

                }
            })
        });
        // products-carousel
        $(document).ready(function() {
            $('#products-owl-carousel').owlCarousel({
                loop: true,
                margin: 10,
                nav: true,
                autoPlay: 3000,
                items: 6, // THIS IS IMPORTANT
                responsive: {
                    480: {
                        items: 1
                    }, // from zero to 480 screen width 1 items
                    768: {
                        items: 2
                    }, // from 480 screen widthto 768 2 items
                    1024: {
                        items: 3
                    }, // from 768 screen width to 1024 3 items
                    1200: {
                        items: 5
                    }, // from 768 screen width to 1024 4 items
                    1920: {
                        items: 6
                    } // from 768 screen width to 1024 5 items

                }
            })
        });
    </script>
     <script>
        // make filters and sort style
        var x, i, j, l, ll, selElmnt, a, b, c;
        /*look for any elements with the class "custom-select":*/
        x = document.getElementsByClassName("custom-select");
        l = x.length;
        for (i = 0; i < l; i++) {
            selElmnt = x[i].getElementsByTagName("select")[0];
            ll = selElmnt.length;
            /*for each element, create a new DIV that will act as the selected item:*/
            a = document.createElement("DIV");
            a.setAttribute("class", "select-selected");
            a.innerHTML = selElmnt.options[selElmnt.selectedIndex].innerHTML;
            x[i].appendChild(a);
            /*for each element, create a new DIV that will contain the option list:*/
            b = document.createElement("DIV");
            b.setAttribute("class", "select-items select-hide");
            for (j = 1; j < ll; j++) {
                /*for each option in the original select element,
                create a new DIV that will act as an option item:*/
                c = document.createElement("DIV");
                c.innerHTML = selElmnt.options[j].innerHTML;
                c.addEventListener("click", function(e) {
                    /*when an item is clicked, update the original select box,
                    and the selected item:*/
                    var y, i, k, s, h, sl, yl;
                    s = this.parentNode.parentNode.getElementsByTagName("select")[0];
                    sl = s.length;
                    h = this.parentNode.previousSibling;
                    for (i = 0; i < sl; i++) {
                        if (s.options[i].innerHTML == this.innerHTML) {
                            s.selectedIndex = i;
                            h.innerHTML = this.innerHTML;
                            y = this.parentNode.getElementsByClassName("same-as-selected");
                            yl = y.length;
                            for (k = 0; k < yl; k++) {
                                y[k].removeAttribute("class");
                            }
                            this.setAttribute("class", "same-as-selected");
                            break;
                        }
                    }
                    h.click();
                });
                b.appendChild(c);
            }
            x[i].appendChild(b);
            a.addEventListener("click", function(e) {
                /*when the select box is clicked, close any other select boxes,
                and open/close the current select box:*/
                e.stopPropagation();
                closeAllSelect(this);
                this.nextSibling.classList.toggle("select-hide");
                this.classList.toggle("select-arrow-active");
            });
        }

        function closeAllSelect(elmnt) {
            /*a function that will close all select boxes in the document,
            except the current select box:*/
            var x, y, i, xl, yl, arrNo = [];
            x = document.getElementsByClassName("select-items");
            y = document.getElementsByClassName("select-selected");
            xl = x.length;
            yl = y.length;
            for (i = 0; i < yl; i++) {
                if (elmnt == y[i]) {
                    arrNo.push(i)
                } else {
                    y[i].classList.remove("select-arrow-active");
                }
            }
            for (i = 0; i < xl; i++) {
                if (arrNo.indexOf(i)) {
                    x[i].classList.add("select-hide");
                }
            }
        }
        /*if the user clicks anywhere outside the select box,
        then close all select boxes:*/
        document.addEventListener("click", closeAllSelect);
     



        $(document).ready(function() {    
    $('.posts_list').simpleLoadMore({
      item: 'div.load-item',
      count: 8,
      itemsToLoad: 8,
      btnHTML: '<div class="row text-center"><div class="col"><div class="loding-more"><a href="#"><img src="<?php bloginfo('template_directory') ?>/images/simple-logo.png" /><h3>Loading More</h3></a></div></div></div>',
    });
    $('.related_list').simpleLoadMore({
      item: 'div.load-item',
      count: 4,
      itemsToLoad: 4,
      btnHTML: '<div class="row text-center"><div class="col"><div class="loding-more"><a href="#"><img src="<?php bloginfo('template_directory') ?>/images/simple-logo.png" /><h3>Loading More</h3></a></div></div></div>',
    });
});


function searchToggle(obj, evt){
    var container = $(obj).closest('.search-wrapper');
        if(!container.hasClass('active')){
            container.addClass('active');
            evt.preventDefault();
        }
        else if(container.hasClass('active') && $(obj).closest('.input-holder').length == 0){
            container.removeClass('active');
            // clear input
            container.find('.search-input').val('');
        }
}

    
  </script>
</body>

<?php wp_footer(); ?>
</body>
</html>