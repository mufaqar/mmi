<!DOCTYPE html>
<html lang="en" class="no-js">
<head>
		<meta charset="UTF-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
	<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />
	<?php if (is_search()) { ?>
	   <meta name="robots" content="noindex, nofollow" /> 
	<?php } ?>
		<title>
			<?php
				/*
				 * Print the <title> tag based on what is being viewed.
				 */
				global $page, $paged, $post;
			
				wp_title( '|', true, 'right' );
			
				// Add the blog name.
				bloginfo( 'name' );
			
				// Add the blog description for the home/front page.
				$site_description = get_bloginfo( 'description', 'display' );
				if ( $site_description && ( is_home() || is_front_page() ) )
					echo " | $site_description";
			
				// Add a page number if necessary:
				if ( $paged >= 2 || $page >= 2 )
					echo ' | ' . sprintf( __( 'Page %s', 'wpv' ), max( $paged, $page ) );
            ?>
	</title>
    <link rel="shortcut icon" href="<?php bloginfo('template_directory'); ?>/images/favicon.png" />
	

	<link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/css/font-awesome.min.css">
    <link rel="stylesheet" href="http://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.min.css">
    <link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/css/style.css">
    <link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/css/owl.carousel.css">
    <link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/css/owl.theme.css">
	<link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>" />
   	<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />
	<?php if ( is_singular() ) wp_enqueue_script('comment-reply'); ?>
	<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
 <!-- Header Start Here -->
 <header class="header">
        <!-- This header show on grater then 1200px width devices -->
        <div id="header-desktop" class="top-header">
            <div class="container">
                <div class="navbar navbar-expand-lg bg-transparent navbar-light p-0">
                    <div class="row">
                        <div class="col-3 my-auto">
                            <div class="site-logo">
                                <a href="<?php bloginfo('url'); ?>"><img src="<?php bloginfo('template_directory'); ?>/images/main-logo.png" alt="Al Baker"></a>
                            </div>
                        </div>
                        <div class="col-6 my-auto">
                            <div class="collapse navbar-collapse" id="collapsibleNavbar">


                            <?php
                            wp_nav_menu( array(
                                'theme_location'  => 'primary',
                                'depth'           => 2, // 1 = no dropdowns, 2 = with dropdowns.
                                'container'       => 'div',
                                'container_class' => 'collapse navbar-collapse',
                                'container_id'    => 'bs-example-navbar-collapse-1',
                                'menu_class'      => 'nav navbar-nav navbar-right',
                                'fallback_cb'     => 'WP_Bootstrap_Navwalker::fallback',
                                'walker'          => new WP_Bootstrap_Navwalker(),
                            ) );

                            ?>


                               
                            </div>
                        </div>
                        <div class="col-3 my-auto">
                            <div class="header-right">
                                <span class="social-icon">
                                <a href="https://www.facebook.com/iffco.albaker/" target="_blank"><i class="fa fa-facebook-f"></i></a>
                                <a href="https://www.instagram.com/al_baker.iffco" target="_blank"><i class="fa fa-instagram"></i></a>
                                <a href="https://twitter.com/iffcoalbaker" target="_blank"><i class="fa fa-twitter"></i></a>
                        </span>
                          <span class="language-switch">
                        <?php if(ICL_LANGUAGE_CODE=='ar'): ?>
                            <a href="http://demo.mufaqar.com/dev2">English</a>
                            <?php elseif(ICL_LANGUAGE_CODE=='en'): ?>
                                <a href="<?php bloginfo('url'); ?>/ar">العربية</a>
                            <?php endif; ?>
                            </span>

                       

                        <span class="search-wrapper">
                        <form action="<?php echo home_url( '/' ); ?>" method="get">
    <div class="input-holder">
        <input type="text" class="search-input" placeholder="Search Site"    name="s" id="search" value="<?php the_search_query(); ?>" />
        <input type="hidden" name="post_type" value="recipes" />
        <button class="search-icon" onclick="searchToggle(this, event);"><i class="fa fa-search"></i></button>
    </div>
    <span class="close" onclick="searchToggle(this, event);"></span>
                            </form>
                            </span>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- This header show on less then 1200px width devices -->
        <div id="header-mobile" class="top-header">
            <div class="container">
                <div class="row">
                    <div class="col-lg-2 col-md-2 col-sm-2 col-3 my-auto">
                        <div class="site-logo">
                            <a href="<?php bloginfo('url'); ?>"><img src="<?php bloginfo('template_directory'); ?>/images/main-logo.png" alt="Al Baker"></a>
                        </div>
                    </div>
                    <div class="col-lg-10 col-md-10 col-sm-10 col-9 my-auto">
                        <div class="row">
                            <div class="col-lg-12 col-md-6 col-sm-5 col-9 my-auto">
                                <nav class="navbar navbar-expand-lg bg-transparent navbar-light p-0">
                                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#menubar">
                              <span class="navbar-toggler-icon"></span>
                            </button>

                            <?php
                            wp_nav_menu( array(
                                'theme_location'  => 'primary',
                                'depth'           => 2, // 1 = no dropdowns, 2 = with dropdowns.
                                'container'       => 'div',
                                'container_class' => 'collapse navbar-collapse',
                                'container_id'    => 'menubar',
                                'menu_class'      => 'nav navbar-nav navbar-right',
                                'fallback_cb'     => 'WP_Bootstrap_Navwalker::fallback',
                                'walker'          => new WP_Bootstrap_Navwalker(),
                            ) );

                            ?>
                                    
                                </nav>
                            </div>
                            <div class="col-lg-12 col-md-6 col-sm-7 col-3 my-auto">
                                <div class="header-right">
                                    <span class="social-icon">
                                    <a href="https://www.facebook.com/iffco.albaker/" target="_blank"><i class="fa fa-facebook-f"></i></a>
                                    <a href="https://www.instagram.com/al_baker.iffco" target="_blank"><i class="fa fa-instagram"></i></a>
                                    <a href="https://twitter.com/iffcoalbaker" target="_blank"><i class="fa fa-twitter"></i></a>
                                </span>
                                <span class="language-switch">
                        <?php if(ICL_LANGUAGE_CODE=='ar'): ?>
                            <a href="http://demo.mufaqar.com/dev2">English</a>
                            <?php elseif(ICL_LANGUAGE_CODE=='en'): ?>
                                <a href="<?php bloginfo('url'); ?>/ar">العربية</a>
                            <?php endif; ?>

                        </span>
                                    <span class="search">
                                    <a href="#"><i class="fa fa-search"></i></a>
                                </span>
                                </div>
                            </div>
                        </div>

                    </div>

                </div>
            </div>
        </div>
        <!-- This header show on less then 991px width devices -->
        <div id="header-mobile-small" class="top-header">
            <div class="container">
                <div class="row">
                    <div class="col-lg-2 col-md-2 col-sm-2 col-4 my-auto">
                        <div class="site-logo">
                            <a href="<?php bloginfo('url'); ?>"><img src="<?php bloginfo('template_directory'); ?>/images/main-logo.png" alt="Al Baker"></a>
                        </div>
                    </div>
                    <div class="col-lg-10 col-md-10 col-sm-10 col-8 my-auto">
                        <div class="row">
                            <div class="col-lg-12 col-md-6 col-sm-5 col-8 my-auto">
                                <nav class="navbar navbar-expand-lg bg-transparent navbar-light p-0">
                                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#mobilemenu">
                              <span class="navbar-toggler-icon"></span>
                            </button>

                                </nav>
                            </div>
                            <div class="col-lg-12 col-md-6 col-sm-7 col-4 my-auto">
                                <div class="header-right">
                                    <span class="social-icon">
                                    <a href="https://www.facebook.com/iffco.albaker/" target="_blank"><i class="fa fa-facebook-f"></i></a>
                                    <a href="https://www.instagram.com/al_baker.iffco" target="_blank"><i class="fa fa-instagram"></i></a>
                                    <a href="https://twitter.com/iffcoalbaker" target="_blank"><i class="fa fa-twitter"></i></a>
                                </span>
                                <span class="language-switch">
                        <?php if(ICL_LANGUAGE_CODE=='ar'): ?>
                            <a href="http://demo.mufaqar.com/dev2">English</a>
                            <?php elseif(ICL_LANGUAGE_CODE=='en'): ?>
                                <a href="<?php bloginfo('url'); ?>/ar">العربية</a>
                            <?php endif; ?>

                        </span>
                                    <span class="search">
                                    <a href="#"><i class="fa fa-search"></i></a>
                                </span>
                                </div>
                            </div>
                        </div>

                    </div>

                </div>
            </div>
            <nav class="navbar navbar-expand-lg bg-transparent navbar-light p-0">
                            <?php
                            wp_nav_menu( array(
                                'theme_location'  => 'primary',
                                'depth'           => 2, // 1 = no dropdowns, 2 = with dropdowns.
                                'container'       => 'div',
                                'container_class' => 'collapse navbar-collapse',
                                'container_id'    => 'mobilemenu',
                                'menu_class'      => 'nav navbar-nav navbar-right',
                                'fallback_cb'     => 'WP_Bootstrap_Navwalker::fallback',
                                'walker'          => new WP_Bootstrap_Navwalker(),
                            ) );

                            ?> 
                                </nav>
        </div>
    </header>


