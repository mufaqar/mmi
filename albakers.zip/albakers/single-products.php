<?php get_header(); ?>
<div class="desktop">
   <section class="single-page">
   <div class="single-page-bg"> </div>
      <div class="container">
         <div class="row top-area">
            <!-- description area -->
            <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12">
               <div class="product-detail">
               <div class="product-detail_icon"> </div>
                  <div class="breadcrumb-style p-0">
                  <ol class="breadcrumb px-0 bg-transparent m-0">
                                    <li class="breadcrumb-item"><a href="<?php echo home_url(); ?>"><?php _e( 'HOME', 'albaker_ts' ); ?></a></li>
                                    <li class="breadcrumb-item " aria-current="page"><a href="<?php echo home_url(); ?>/albaker-products"><?php _e( 'Products', 'albaker_ts' ); ?></a></li>
                                    <li class="breadcrumb-item active" aria-current="page"><?php the_title(); ?></li>
                                </ol>
                  </div>
                  <div class="product-title">
                     <h2><?php the_title()?></h2>
                  </div>
                  <div class="row">
                     <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12 p-0">
                        <div class="review-area">
                           <?php get_template_part('inc/rating') ?>
                        </div>
                     </div>
                     <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12 p-0">
                        <?php get_template_part('inc/share') ?>
                     </div>
                  </div>
                  <div class="product-description">
                     <?php the_content()?>
                     <p>
                     <h4><?php _e( 'Features & Benefits', 'albaker_ts' ); ?></h4>
                     <?php the_field('features_benefits'); ?>
                     </p>
                  </div>
               </div>
            </div>
            <!-- gallery area-->
            <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12">
               <div class="gallery-carousel">
                  <?php get_template_part('inc/gallery') ?>
               </div>
            </div>
         </div>
      </div>
   </section>
</div>
<div class="mobile">
   <section class="single-page">
      <div class="container">
         <div class="row top-area">
            <!-- description area -->
            <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12">
               <div class="product-detail">
                  <div class="breadcrumb-style p-0">
                         <ol class="breadcrumb px-0 bg-transparent m-0">
                                    <li class="breadcrumb-item"><a href="<?php echo home_url(); ?>"><?php _e( 'HOME', 'albaker_ts' ); ?></a></li>
                                    <li class="breadcrumb-item " aria-current="page"><a href="<?php echo home_url(); ?>/albaker-products"><?php _e( 'Products', 'albaker_ts' ); ?></a></li>
                                    <li class="breadcrumb-item active" aria-current="page"><?php the_title(); ?></li>
                                </ol>
                  </div>
                  <div class="product-title">
                     <h2><?php the_title()?></h2>
                  </div>
                  <div class="row">
                  <div class="gallery-carousel">
                     <?php get_template_part('inc/gallery') ?>
                  </div>
                                 
                  <div class="row">
                     <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12 p-0">
                        <div class="review-area">
                           <?php get_template_part('inc/rating') ?>
                        </div>
                     </div>
                     <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12 p-0">
                        <?php get_template_part('inc/share') ?>
                     </div>
                  </div>
                  <div class="product-description">
                     <?php the_content()?>
                     <p>
                     <h4><?php _e( 'Features & Benefits', 'albaker_ts' ); ?></h4>
                     <?php the_field('features_benefits'); ?>
                     </p>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </section>
</div>
<?php
   // get_template_part('temp-related');
    
    
    ?>
<!-- Related Recipes -->
<div class="related-recipes">
 <div class="top-albaker-Collections">
        </div>
   <div class="container">
      <div class="row">
         <div class="col">
            <div class="main-title text-center">
             <?php _e( 'Related Recipes', 'albaker_ts' ); ?>
            </div>
         </div>
      </div>
      <div class="row related_list">
         <?php
            $rid = get_the_ID();
            
            
            
            
            $args = array(
                'post_type' => 'recipes',
                'posts_per_page' => -1,
                'meta_query' => array(
                   array(
                      'key'     => 'perfect_for_this_recipe',
                      'value'   => serialize(array(''.$rid.'')),
                      'compare' => 'LIKE',
                   ),
                 ),
               );
            
              // print_r($args);
            
            
            
            
                // The Query
                $the_query = new WP_Query( $args );
            
                // The Loop
                if ( $the_query->have_posts() ) {
            
                    while ( $the_query->have_posts() ) : $the_query->the_post(); 
                    get_template_part('template-part/recipes','layout');
                    endwhile;
            
                } else {
                    echo "<center><h2> ".__( 'Sorry No Related Recipe Found', 'albaker_ts' ) ."    </h2></center>";
                }
                /* Restore original Post Data */
                wp_reset_postdata();
            
            
                ?>
      </div>
   </div>
</div>
 <!-- Signup Section Start Here -->
 <?php get_template_part('inc/newletter'); ?>
     <!-- End Signup Section Start Here -->
<?php get_footer(); ?>