<?php

/// Recipe Page Filters



add_action('wp_ajax_get_recepies_by_sorting', 'get_recepies_by_sorting', 0);
add_action('wp_ajax_nopriv_get_recepies_by_sorting', 'get_recepies_by_sorting');
function get_recepies_by_sorting() {
	 

      $cname = stripcslashes($_POST['cname']);
      
	   query_posts(array(
        'post_type' => 'recipes',
        'posts_per_page' => -1,
        'order'   => $cname,
        
    )); 
    if (have_posts()) :  while (have_posts()) : the_post();   

     get_template_part('template-part/recipes','layout');
     
     endwhile; wp_reset_query(); else : ?>
        <h2><?php _e('Nothing Found','albaker_ts'); ?></h2>
        <?php endif; 
		die;
}




add_action('wp_ajax_get_post_by_tags', 'get_post_by_tags', 0);
add_action('wp_ajax_nopriv_get_post_by_tags', 'get_post_by_tags');
function get_post_by_tags() {
	 
	 // Get Form Data
      $cname = stripcslashes($_POST['cname']);
      
	   query_posts(array(
        'post_type' => 'recipes',
        'posts_per_page' => -1,
        'recipe_tags' => $cname
        
    )); 
    if (have_posts()) :  while (have_posts()) : the_post();   

     get_template_part('template-part/recipes','layout');
     
     endwhile; wp_reset_query(); else : ?>
        <h2><?php _e('Nothing Found','albaker_ts'); ?></h2>
        <?php endif; 
		die;
}



add_action('wp_ajax_get_post_by_products', 'get_post_by_products', 0);
add_action('wp_ajax_nopriv_get_post_by_products', 'get_post_by_products');
function get_post_by_products() {
	 
	
      $cname = stripcslashes($_POST['cname']);
      
	   query_posts(array(
        'post_type' => 'recipes',
        'posts_per_page' => -1,
        'meta_query' => array(
            array(
               'key'     => 'perfect_for_this_recipe',
               'value'   => serialize(array(''.$cname.'')),
               'compare' => 'LIKE',
            ),
          ),
        
        
    )); 
    if (have_posts()) :  while (have_posts()) : the_post();  

     get_template_part('template-part/recipes','layout');
     
     endwhile; wp_reset_query(); else : ?>
        <h2><?php _e('Nothing Found','albaker_ts'); ?></h2>
        <?php endif; 
		die;
}


add_action('wp_ajax_get_post_by_occasion', 'get_post_by_occasion', 0);
add_action('wp_ajax_nopriv_get_post_by_occasion', 'get_post_by_occasion');
function get_post_by_occasion() {
	 
      $cname = stripcslashes($_POST['cname']);      
	   query_posts(array(
        'post_type' => 'recipes',
        'posts_per_page' => -1,
        'occasions' => $cname
        
    )); 
    if (have_posts()) :  while (have_posts()) : the_post();  

     get_template_part('template-part/recipes','layout');
     
     endwhile; wp_reset_query(); else : ?>
        <h2><?php _e('Nothing Found','albaker_ts'); ?></h2>
        <?php endif; 
		die;
}


add_action('wp_ajax_get_post_by_cates', 'get_post_by_cates', 0);
add_action('wp_ajax_nopriv_get_post_by_cates', 'get_post_by_cates');
function get_post_by_cates() {
	 
	 // Get Form Data
      $cname = stripcslashes($_POST['cname']);
      
	   query_posts(array(
        'post_type' => 'recipes',
        'posts_per_page' => -1,
        'categories' => $cname
        
    )); 
    if (have_posts()) :  while (have_posts()) : the_post(); 

   

     get_template_part('template-part/recipes','layout');
     
     endwhile; wp_reset_query(); else : ?>
        <h2><?php _e('Nothing Found','albaker_ts'); ?></h2>
        <?php endif; 
		die;
}






// Albaker Page Filters

add_action('wp_ajax_get_albakers_by_cat', 'get_albakers_by_cat', 0);
add_action('wp_ajax_nopriv_get_albakers_by_cat', 'get_albakers_by_cat');
function get_albakers_by_cat() {
	 

      $cname = stripcslashes($_POST['cname']);  
      
	   query_posts(array(
        'post_type' => 'albakers',
        'posts_per_page' => -1,
        'albaker_categories' => $cname,
        
        
        
    )); 
    if (have_posts()) :  while (have_posts()) : the_post();    

     get_template_part('template-part/albaker','layout');
     
     endwhile; wp_reset_query(); else : ?>
        <h2><?php _e('Nothing Found','albaker_ts'); ?></h2>
        <?php endif; 
		die;
}


add_action('wp_ajax_get_albakers_by_sorting', 'get_albakers_by_sorting', 0);
add_action('wp_ajax_nopriv_get_albakers_by_sorting', 'get_albakers_by_sorting');
function get_albakers_by_sorting() {
	 
	 // Get Form Data
      $cname = stripcslashes($_POST['cname']);
      
	   query_posts(array(
        'post_type' => 'albakers',
        'posts_per_page' => -1,
        'order'   => $cname,
        
    )); 
    if (have_posts()) :  while (have_posts()) : the_post();   

    get_template_part('template-part/albaker','layout');
     
     endwhile; wp_reset_query(); else : ?>
        <h2><?php _e('Nothing Found','albaker_ts'); ?></h2>
        <?php endif; 
		die;
}







// Ajax Product Page



add_action('wp_ajax_get_product_by_tags', 'get_product_by_tags', 0);
add_action('wp_ajax_nopriv_get_product_by_tags', 'get_product_by_tags');
function get_product_by_tags() {
	 
	 // Get Form Data
      $cname = stripcslashes($_POST['cname']);
     
      
      query_posts(array(
        'post_type' => 'recipes',
        'posts_per_page' => -1,
        'occasions' => $cname
        
    )); 
    if (have_posts()) :  while (have_posts()) : the_post(); 
    $photo = get_field('perfect_for_this_recipe');

        //print_r($photo);

        $product_id =  $photo[0];

        $post_7 = get_post( $product_id ); 

       // print_r($post_7);

        $title = $post_7->post_title;   

     get_template_part('template-part/product','layout');
     
     endwhile; wp_reset_query(); else : ?>
        <h2><?php _e('Nothing Found','albaker_ts'); ?></h2>
        <?php endif; 
		die;
}


add_action('wp_ajax_get_products_by_cat', 'get_products_by_cat', 0);
add_action('wp_ajax_nopriv_get_products_by_cat', 'get_products_by_cat');
function get_products_by_cat() {
	 
	 // Get Form Data
      $cname = stripcslashes($_POST['cname']);
     
      
      query_posts(array(
        'post_type' => 'products',
        'posts_per_page' => -1,
        'pro_categories' => $cname
        
    )); 
    if (have_posts()) :  while (have_posts()) : the_post(); 
     get_template_part('template-part/products','layout');
     
     endwhile; wp_reset_query(); else : ?>
        <h2><?php _e('Nothing Found','albaker_ts'); ?></h2>
        <?php endif; 
		die;
}



add_action('wp_ajax_get_products_by_region', 'get_products_by_region', 0);
add_action('wp_ajax_nopriv_get_products_by_region', 'get_products_by_region');
function get_products_by_region() {
	 
	 // Get Form Data
      $cname = stripcslashes($_POST['cname']);
     
      
      query_posts(array(
        'post_type' => 'products',
        'posts_per_page' => -1,
        'region' => $cname
        
    )); 
    if (have_posts()) :  while (have_posts()) : the_post(); 
     get_template_part('template-part/products','layout');
     
     endwhile; wp_reset_query(); else : ?>
        <h2><?php _e('Nothing Found','albaker_ts'); ?></h2>
        <?php endif; 
		die;
}




add_action('wp_ajax_get_carosel', 'get_carosel', 0);
add_action('wp_ajax_nopriv_get_carosel', 'get_carosel');
function get_carosel() {
	 
    $cname = stripcslashes($_POST['cname']);
     
      
    query_posts(array(
      'post_type' => 'recipes',
      'posts_per_page' => -1,
      'categories' => $cname
      
  )); 

  echo '<div id="ajax-carosel" class="owl-carousel grid">';

  if (have_posts()) :  while (have_posts()) : the_post();
   
   get_template_part('template-part/carosel','layout');
   
   endwhile; wp_reset_query();
   
   echo '</div>';
   else : ?>
      <h2><?php _e('Nothing Found','albaker_ts'); ?></h2>
      <?php endif; 
      die;
}

