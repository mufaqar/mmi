<?php

function blog_scripts() {
    // Register the script
    wp_register_script( 'custom-script', get_stylesheet_directory_uri(). '/js/custom.js', array('jquery'), false, true );
 
    // Localize the script with new data
    $script_data_array = array(
        'ajaxurl' => admin_url( 'admin-ajax.php' ),
        'security' => wp_create_nonce( 'load_more_posts' ),
    );
    wp_localize_script( 'custom-script', 'blog', $script_data_array );
 
    // Enqueued script with localized data.
    wp_enqueue_script( 'custom-script' );
}
add_action( 'wp_enqueue_scripts', 'blog_scripts' );


function albaker_scripts() {
    // Register the script
    wp_register_script( 'custom-script', get_stylesheet_directory_uri(). '/js/custom.js', array('jquery'), false, true );
 
    // Localize the script with new data
    $script_data_array = array(
        'ajaxurl' => admin_url( 'admin-ajax.php' ),
        'security' => wp_create_nonce( 'load_more_albakers' ),
    );
    wp_localize_script( 'custom-script', 'blog', $script_data_array );
 
    // Enqueued script with localized data.
    wp_enqueue_script( 'custom-script' );
}
add_action( 'wp_enqueue_scripts', 'albaker_scripts' );



add_action('wp_ajax_load_posts_by_ajax', 'load_posts_by_ajax_callback');
add_action('wp_ajax_nopriv_load_posts_by_ajax', 'load_posts_by_ajax_callback');

function load_posts_by_ajax_callback() {
    check_ajax_referer('load_more_posts', 'security');
    $paged = $_POST['page'];
    $args = array(
        'post_type' => 'post',
        'post_status' => 'publish',
        'posts_per_page' => '-1',
        'paged' => $paged,
    );
    $blog_posts = new WP_Query( $args );
     if ( $blog_posts->have_posts() ) : 
      while ( $blog_posts->have_posts() ) : $blog_posts->the_post(); 
      get_template_part('template-part/blog','layout');
         endwhile; 
    endif; 
    wp_die();
}



add_action('wp_ajax_load_akbaker_by_ajax', 'load_akbaker_by_ajax_callback');
add_action('wp_ajax_nopriv_load_akbaker_by_ajax', 'load_akbaker_by_ajax_callback');

function load_akbaker_by_ajax_callback() {
 
    $paged = $_POST['page'];
    $args = array(
        'post_type' => 'albakers',
        'post_status' => 'publish',
        'posts_per_page' => '6',
        'paged' => $paged,
    );
    $blog_posts = new WP_Query( $args );
     if ( $blog_posts->have_posts() ) : 
      while ( $blog_posts->have_posts() ) : $blog_posts->the_post(); 
      get_template_part('template-part/albaker','layout');
         endwhile; 
    endif; 
    wp_die();
}
