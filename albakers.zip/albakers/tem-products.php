<?php  /* Template Name: Producuts */ get_header(); ?>

<section>
        <div class="page-main-area products" >
            <div class="container">
                <div class="row">
                    <div class="col">
                        <div class="main-title"><?php the_title()?></div>
                        <div class="breadcrumb-style">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb px-0 bg-transparent m-0">
                                    <li class="breadcrumb-item"><a href="#"><?php _e( 'HOME', 'albaker_ts' ); ?></a></li>
                                    <li class="breadcrumb-item active" aria-current="page"><?php _e( 'PRODUCTS', 'albaker_ts' ); ?></li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- AlBaker World Blog Start Here -->
    <section class="product-page">
        <!-- Filters Start Here -->
        <div class="filters">
            <div class="container">
                <div class="row">
                    <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6 col-12">
                    <div class="custom-select tags">
                        <?php
                                
                                $tex_recipe_tags = get_terms( array('taxonomy' => 'pro_categories','hide_empty' => false ) );
                                            
                                            if ( !empty($tex_recipe_tags) ) :
                                                $output = '<select id="tags">';
                                                $output.= '<option hidden >'.__( 'Cuisine', 'albaker_ts' ) .'</option>';
                                                foreach( $tex_recipe_tags as $tex_recipe_tag ) {
                                                    $output.= '<option value="'. esc_attr( $tex_recipe_tag->slug ) .'">'. esc_html( $tex_recipe_tag->name ) .'</option>';

                                                }
                                                $output.='</select>';
                                                echo $output;
                                            endif;

                                            ?>
                        </div>
                    </div>
                    <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6 col-12">
                    <div class="custom-select region">
                          
                          <?php  $tex_occasions = get_terms( array('taxonomy' => 'region','hide_empty' => false ) );
                                            
                                 if ( !empty($tex_occasions) ) :
                                                $output = '<select id="filters_region">';                                            
                                                $output.= '<option hidden >'.__( 'Region', 'albaker_ts' ) .'</option>';
                                                foreach( $tex_occasions as $tex_occasion ) {
                                                    $output.= '<option value="'. esc_attr( $tex_occasion->slug ) .'">
                                                    '. esc_html( $tex_occasion->name ) .'</option>';

                                                }
                                                $output.='</select>';
                                                echo $output;
                                   endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- product listing Start Here -->
        <div class="product-grid">
            <div class="container">

            <div class="row load_post">  

        
            


                  </div>   

                <div class="row nonajax posts_list">

                <?php query_posts(array(
            'post_type' => 'products',
            'posts_per_page' => 10,
			'order' => 'desc'
			
        )); 
		if (have_posts()) :  while (have_posts()) : the_post(); ?>
                    <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 col-12">
                        <div class="single-product">
                            <div class="product-image">
                                <a href="<?php the_permalink()?>">                            
                                <?php if ( has_post_thumbnail() ) {
									the_post_thumbnail('product-thumbnail');
								} else { ?>
							<img src="<?php bloginfo('template_directory'); ?>/images/product-1.jpg" alt="Featured Thumbnail" />
							<?php } ?>
                            </a>
                            </div>
                            <div class="single-product-body">
                                <a href="<?php the_permalink()?>">
                                    <div class="product-title"><?php the_title()?></div>
                                </a>
                            </div>
                        </div>
                    </div>
                    <?php endwhile; wp_reset_query(); else : ?>
			<h2><?php _e('Nothing Found','albaker_ts'); ?></h2>
	        <?php endif; ?> 
                </div>
            </div>
        </div>
        </div>
    </section>
     <!-- Signup Section Start Here -->
     <?php get_template_part('inc/newletter'); ?>
     <!-- End Signup Section Start Here -->
  
  
<?php get_footer(); ?>

<script type="text/javascript">
// ajax occasion
  $(".region").on("click", function() {

   
    
    var occasion = $('#filters_region :selected').val();
   jQuery.ajax({
         type:"POST",
         url:"<?php echo admin_url('admin-ajax.php'); ?>",
         data: {
           action: "get_products_by_region",
           cname : occasion,		
         },
         success: function(response){
           $( ".nonajax" ).hide();
                  
          $( ".load_post" ).html( response );
         }
       });

});


$(".tags").on("click", function() {

var ctags =  $('#tags :selected').val(); 

jQuery.ajax({
      type:"POST",
      url:"<?php echo admin_url('admin-ajax.php'); ?>",
      data: {
        action: "get_products_by_cat",
        cname : ctags,		
      },
      success: function(response){
        $( ".nonajax" ).hide();             
       $( ".load_post" ).html( response );
      }
    });

});








</script>