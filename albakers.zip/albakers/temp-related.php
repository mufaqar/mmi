 <!-- Related Recipes -->
 <div class="related-recipes">
 <div class="top-albaker-Collections">
        </div>
        <div class="container">
            <div class="row">
                <div class="col">
                    <div class="main-title text-center">
                        <?php _e( 'Related Recipes', 'albaker_ts' ); ?>
                    </div>
                </div>
            </div>
            <div class="row related_list">
            <?php

                $terms_categories = get_the_terms( $post->ID, 'categories' );
                if ( !empty( $terms_categories ) ){
                    // get the first term
                    $get_terms_categories = array_shift( $terms_categories );
                    $related_categorie =  $get_terms_categories->slug;
                }
    
            
            
            query_posts(array(
            'post_type' => 'recipes',
            'posts_per_page' => -1,
			'categories' => $related_categorie
			
        )); 
		if (have_posts()) :  while (have_posts()) : the_post(); 

                get_template_part('template-part/recipes','layout');
               endwhile; wp_reset_query(); else : ?>
			<h2><?php _e('Nothing Found','albaker_ts'); ?></h2>
	        <?php endif; ?> 
	

            </div>
        </div>
    </div>
    
<!-- Signup Section Start Here -->
<?php get_template_part('inc/newletter'); ?>
     <!-- End Signup Section Start Here -->