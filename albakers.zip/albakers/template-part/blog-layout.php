                    <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 load-item">
                                <div class="single-blog">
                                    <a href="<?php the_permalink()?>">
                                        <div class="post-type"></div>
                                        <div class="blog-image">
                                            <?php if ( has_post_thumbnail() ) {
                                                the_post_thumbnail('blog-thumbnail');
                                            } else { ?>
                                    <img src="<?php bloginfo('template_directory'); ?>/images/news-1.jpg">
                                        <?php } ?>

                                        </div>
                                        <div class="single-blog-body">
                                            <div class="blog-title"><?php the_title()?></div>
                                        </div>
                                    </a>
                                </div>
                    </div>