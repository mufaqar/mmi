<section class="signup">
        <div class="container">
            <div class="row">
                <div class="col-xl-5 col-lg-5 col-md-12 col-sm-12 col-12">
                    <div class="signup-text">
                        <h4><?php _e( 'Stay Up To Date with Our Products & Recipes', 'albaker_ts' ); ?></h4>
                    </div>
                </div>
                <div class="col-xl-7 col-lg-7 col-md-12 col-sm-12 col-12">
                    <div class="signup-form">
                        <form class="form-inline" action="">
                            <input type="email" class="form-control" id="email" placeholder="<?php _e( 'Your Email Address', 'albaker_ts' ); ?>" name="email">
                            <button type="submit" class="btn site-btn "><?php _e( 'DISCOVER ALL', 'albaker_ts' ); ?></button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
</section>