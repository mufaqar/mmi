<?php /* Template Name: Home */ get_header(); ?>
	

  <!-- Carousel Start Here -->
  <section class="Carousel-slider">
        <div id="maincarousel" class="carousel slide" data-ride="carousel">
            <!-- Carousel Slides indicators -->
            <ul class="carousel-indicators">
             
               

         <?php query_posts(array(
            'post_type' => 'slides',
            'posts_per_page' => -1,
			'order' => 'desc'
			
        )); 
        $j = -1;
        if (have_posts()) :  while (have_posts()) : the_post(); $j++; ?>
           <li data-target="#maincarousel" data-slide-to="<?php echo $j ?>" class="<?php if ($j == "1") { echo "active";} ?>"></li>
        <?php endwhile; wp_reset_query(); else : ?>
			<h2><?php _e('Nothing Found','albaker_ts'); ?></h2>
	        <?php endif; ?> 

            </ul>
            <div class="carousel-inner">
             

        <?php query_posts(array(
            'post_type' => 'slides',
            'posts_per_page' => -1,
			'order' => 'desc'
			
        )); 
        $i = -1;
		if (have_posts()) :  while (have_posts()) : the_post(); $i++; ?>

                <div class="carousel-item <?php if ($i == "0") { echo "active";} ?>">
                   

                    <?php if ( has_post_thumbnail() ) {
									the_post_thumbnail('full');
								} else { ?>
						 <img src="<?php bloginfo('template_directory'); ?>/images/slide-1.jpg" alt="Slide Image">
							<?php } ?>


                    <div class="carousel-caption">
                        <h4><?php the_title(); ?></h4>
                        <h3><?php the_field('sub_title'); ?></h3>
                        <a href="<?php the_field('btn_link'); ?>" class="btn site-btn"><?php the_field('btn_text'); ?></a>
                    </div>
                </div>
        <?php endwhile; wp_reset_query(); else : ?>
			<h2><?php _e('Nothing Found','albaker_ts'); ?></h2>
	        <?php endif; ?> 
	
              
            </div>
            <!-- Carousel Slides Controls -->
            <a class="carousel-control-prev" href="#maincarousel" data-slide="prev">
                <span class="carousel-control-prev-icon"></span>
            </a>
            <a class="carousel-control-next" href="#maincarousel" data-slide="next">
                <span class="carousel-control-next-icon"></span>
            </a>
        </div>
    </section>
    <!-- Recipe Collections Start Here -->
    <section class="Recipe-Collections">

     <div class="top-Recipe-Collections">
        </div>
        <div class="main-Recipe-Collections">
            <div class="container">
                <div class="row">
                    <div class="col-xl-3 col-lg-12 col-md-12 col-sm-12 col-12">
                        <div class="main-title">
                             <?php _e( 'Recipe Collections', 'albaker_ts' ); ?>
                        </div>
                    </div>
                    <div class="col-xl-9 col-lg-12 col-md-12 col-sm-12 col-12 mt-auto">
                        <div class="filter-btn">
                            <div class="filter-group" id="myBtnContainer">
                                <button class="btn site-btn ajaxbtn"  data-id="<?php echo ICL_LANGUAGE_CODE=='ar' ? 'dessert-ar' : 'dessert';?>"><?php _e( 'Dessert', 'albaker_ts' ); ?></button>
                                <button class="btn site-btn ajaxbtn"  data-id="<?php echo ICL_LANGUAGE_CODE=='ar' ? 'appetizer-ar' : 'appetizer';?>"><?php _e( 'Appetizer', 'albaker_ts' ); ?></button>
                                <button class="btn site-btn ajaxbtn"  data-id="<?php echo ICL_LANGUAGE_CODE=='ar' ? 'savory-ar' : 'savory';?>" ><?php _e( 'Savory', 'albaker_ts' ); ?></button>
                                <a href="<?php echo home_url(); ?>/albaker-recipes" class="btn site-btn active"><?php _e( 'DISCOVER ALL', 'albaker_ts' ); ?></a>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row ajax_post">

                      </div>


                <div class="row normal_post">
                    <div id="Recipes-owl-carousel" class="owl-carousel grid" >
                                <?php query_posts(array(
                                'post_type' => 'recipes',
                                'posts_per_page' => 6,
                                'order' => 'desc'
                                
                            )); 
                            if (have_posts()) :  while (have_posts()) : the_post();         
                                    get_template_part('template-part/homerecipes','layout');
                                endwhile; wp_reset_query(); else : ?>
                                <h2><?php _e('Nothing Found','albaker_ts'); ?></h2>
                                <?php endif; ?>          
                                        
                      </div>


                  
                 </div>
            </div>
        </div>
    </section>
    <!-- AlBaker World Start Here -->
    <section class="AlBaker-World">
    <div class="top-albaker-Collections">
        </div>



        <div class="top-AlBaker-World">
            <div class="row">
                <div class="col">
                    <div class="main-title text-center mb-4">
                        <?php _e( 'AlBaker World', 'albaker_ts' ); ?>
                    </div>
                </div>
            </div>
        </div>
        <div class="main-AlBaker-World blog-grid">
            <div class="container">
                <div class="row">


                <?php query_posts(array(
                    'post_type' => 'albakers',
                    'posts_per_page' => 4,
                    'order' => 'desc'
			
        )); 
        if (have_posts()) :  while (have_posts()) : the_post(); 
        
        get_template_part('template-part/homealbaker','layout');
         endwhile; wp_reset_query(); else : ?>
			<h2><?php _e('Nothing Found','albaker_ts'); ?></h2>
	        <?php endif; ?> 


         <?php  query_posts(array(
                'post_type' => 'albakers',
                'posts_per_page' => 3,
                'order' => 'desc',
                'offset' => '4'
            
			
        )); 
        if (have_posts()) :  while (have_posts()) : the_post(); 
        
        ?>

                    <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12">
                        <div class="single-blog">
                            <a href="<?php the_permalink()?>">
                                <div class="post-type">
                                <?php  Albaker_Post_Type(); ?>
                                </div>
                                <div class="blog-image">
                                    <?php if ( has_post_thumbnail() ) {
									the_post_thumbnail('bakers-thumbnail');
								} else { ?>
							     <img src="<?php bloginfo('template_directory'); ?>/images/blog-1.jpg">
							<?php } ?>

                                </div>
                                <div class="single-blog-body">
                                    <div class="bolg-cat">
                                    <?php
                                        $term_bakers_list = get_the_terms( $post->ID, 'albaker_categories' );
                                        $terms_bakers = join(', ', wp_list_pluck($term_bakers_list, 'name'));
                                        echo $terms_bakers;
                                        ?>

                                    </div>
                                    <div class="blog-title"><?php the_title()?></div>
                                </div>
                            </a>
                        </div>
                    </div>


                    <?php endwhile; wp_reset_query(); else : ?>
			<h2><?php _e('Nothing Found','albaker_ts'); ?></h2>
	        <?php endif; ?> 
	
                    
                   <div class="row text-center">
                    <div class="col">
                        <a href="<?php echo home_url(); ?>/albaker-world/" class="btn site-btn"><?php _e( 'DISCOVER ALL', 'albaker_ts' ); ?></a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Discover Products Start Here -->
    <section class="Discover-Products">

   <div class="top-Products-Collections"></div>


        <div class="row">
            <div class="col">
                <div class="main-title text-center mb-5">
                    <?php _e( 'Discover Products', 'albaker_ts' ); ?>
                </div>
            </div>
        </div>
        <div class="products-carousel">
            <div class="container">
                <div id="products-owl-carousel" class="owl-carousel">

                     
        <?php query_posts(array(
                    'post_type' => 'products',
                    'posts_per_page' => -1,
                    'order' => 'desc'
                    
                )); 
		if (have_posts()) :  while (have_posts()) : the_post(); ?>
                    <div class="item">
                        <a href="<?php the_permalink()?>">
                            <div class="product-item">
                               <?php if ( has_post_thumbnail() ) {
									the_post_thumbnail('product-home-thumbnail');
								} else { ?>
							   <img src="<?php bloginfo('template_directory'); ?>/images/All-Purpose-Flour.png">
							<?php } ?>
                                <h4><?php the_title()?></h4>
                            </div>
                        </a>
                    </div>
                    
		  <?php endwhile; wp_reset_query(); else : ?>
			<h2><?php _e('Nothing Found','albaker_ts'); ?></h2>
	        <?php endif; ?> 
	
                  
                </div>
            </div>
        </div>
    </section>
    <!-- News Start Here -->
    <section class="News blog-grid">
        <div class="container">
            <div class="row">
                <div class="col">
                    <div class="main-title text-center mb-4">
                        <?php _e( 'News', 'albaker_ts' ); ?>
                    </div>
                </div>
            </div>
            <div class="row">
            <?php query_posts(array(
            'post_type' => 'post',
            'posts_per_page' => 3,
			'order' => 'desc'
			
        )); 
		if (have_posts()) :  while (have_posts()) : the_post(); ?>
                     <?php get_template_part('template-part/blog','layout');?> 
                <?php endwhile; wp_reset_query(); else : ?>
			<h2><?php _e('Nothing Found','albaker_ts'); ?></h2>
	        <?php endif; ?> 
              
            </div>
            <div class="row text-center">
                <div class="col">
                    <a href="<?php echo home_url(); ?>/about-us/news-room" class="btn site-btn"><?php _e( 'DISCOVER ALL', 'albaker_ts' ); ?> </a>
                </div>
            </div>
        </div>

    </section>
    <!-- Signup Section Start Here -->
    <?php get_template_part('inc/newletter'); ?>
     <!-- End Signup Section Start Here -->


<?php get_footer(); ?>
<script src="<?php bloginfo('template_directory'); ?>/js/owl.carousel.js"></script>

<script>


$(document).ready(function() {
$(".btn").click(function () {
    $(".btn").removeClass("active");
    $(this).addClass("active");   
});
});
</script>

<script type="text/javascript">
        //Recipe-Collections
        $(document).ready(function() {
            $('#Recipes-owl-carousel').owlCarousel({
                loop: true,
                margin: 10,
                nav: true,
                autoPlay: 3000,
                items: 4, // THIS IS IMPORTANT
                responsive: {
                    480: {
                        items: 1
                    }, // from zero to 480 screen width 1 items
                    768: {
                        items: 2
                    }, // from 480 screen widthto 768 2 items
                    1024: {
                        items: 3
                    }, // from 768 screen width to 1024 3 items
                    1200: {
                        items: 3
                    }, // from 768 screen width to 1024 4 items
                    1920: {
                        items: 4
                    } // from 768 screen width to 1024 5 items

                }
            })
        });
        // products-carousel
        $(document).ready(function() {
            $('#products-owl-carousel').owlCarousel({
                loop: true,
                margin: 10,
                nav: true,
                autoPlay: 3000,
                items: 6, // THIS IS IMPORTANT
                responsive: {
                    480: {
                        items: 1
                    }, // from zero to 480 screen width 1 items
                    768: {
                        items: 2
                    }, // from 480 screen widthto 768 2 items
                    1024: {
                        items: 3
                    }, // from 768 screen width to 1024 3 items
                    1200: {
                        items: 5
                    }, // from 768 screen width to 1024 4 items
                    1920: {
                        items: 6
                    } // from 768 screen width to 1024 5 items

                }
            })
        });
    </script>
    <script>
$(document).ready(function(){
  $(".ajaxbtn").click(function(){



    var prods = $(this).attr("data-id"); 
 
   
   jQuery.ajax({
         type:"POST",
         url:"<?php echo admin_url('admin-ajax.php'); ?>",
         data: {
           action: "get_carosel",
           cname : prods,		
         },
         success: function(response){
           $( ".normal_post" ).hide();
           $( ".ajax_post" ).show();

                  
          $( ".ajax_post" ).html( response );
          var owl = $("#ajax-carosel");
            owl.owlCarousel({
                loop: true,
                margin: 10,
                nav: true,
                autoPlay: 3000,
                items: 4, // THIS IS IMPORTANT
                responsive: {
                    480: {
                        items: 1
                    }, // from zero to 480 screen width 1 items
                    768: {
                        items: 2
                    }, // from 480 screen widthto 768 2 items
                    1024: {
                        items: 3
                    }, // from 768 screen width to 1024 3 items
                    1200: {
                        items: 3
                    }, // from 768 screen width to 1024 4 items
                    1920: {
                        items: 4
                    } // from 768 screen width to 1024 5 items

                }
            });
         }
       });
  });



});
</script>