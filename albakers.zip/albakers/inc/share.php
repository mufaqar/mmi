<div class="share-area">
                                    <?php _e( 'SHARE', 'albaker_ts' ); ?>
                                    <div class="share-icon">
                                        <a  href="https://www.facebook.com/sharer/sharer.php?u=<?php the_permalink()?>" target="_blank"><i class="fa fa-facebook-f"></i></a>
                                        <a href="https://www.instagram.com/" target="_blank"><i class="fa fa-instagram" target="_blank"></i></a>
                                        <a href="https://twitter.com/intent/tweet?url=<?php the_permalink()?>&text=<?php the_title()?>" target="_blank"><i class="fa fa-twitter"></i></a>
                                        <a href="mailto:info@example.com?&subject=&body=<?php the_permalink()?>" target="_blank"><i class="fa fa-envelope-o"></i></a>
                                    </div>
 </div>

                  