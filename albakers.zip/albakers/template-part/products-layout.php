<div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 col-12">
                        <div class="single-product">
                            <div class="product-image">
                                <a href="<?php the_permalink()?>">                            
                                <?php if ( has_post_thumbnail() ) {
									the_post_thumbnail('product-thumbnail');
								} else { ?>
							<img src="<?php bloginfo('template_directory'); ?>/images/product-1.jpg" alt="Featured Thumbnail" />
							<?php } ?>
                            </a>
                            </div>
                            <div class="single-product-body">
                                <a href="<?php the_permalink()?>">
                                    <div class="product-title"><?php the_title()?></div>
                                </a>
                            </div>
                        </div>
                    </div>