<?php
                                        $likes = get_post_meta($post->ID, "votes_count", true);
                                        $likes = ($likes == "") ? 0 : $likes;
                                       // echo $likes;
                                        ?>
                                    <div class="recipe-review <?php if($likes <= "10" ) {  echo "grey-like" ;} ?>">
                                        <span><i class="fa fa-star"></i>
                                             <i class="fa fa-star"></i>
                                             <i class="fa fa-star"></i>
                                             <i class="fa fa-star"></i>
                                             <i class="fa fa-star"></i>
                                        </span>                                       
                                     <span class="recipe-review-text"><?php echo $likes ?><?php _e( 'REVIEWS', 'albaker_ts' ); ?> </span>
                                    </div>