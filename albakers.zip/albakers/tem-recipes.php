<?php  /* Template Name: Recipes */ get_header(); ?>

<section>
        <div class="page-main-area" style="background: url(<?php bloginfo('template_directory'); ?>/images/blur-banner-bar.png) bottom center no-repeat , url(<?php bloginfo('template_directory'); ?>/images/recipes-banner.jpg) top center no-repeat;">
            <div class="container">
                <div class="row">
                    <div class="col">
                    <div class="main-title"><?php the_title()?></div>
                        <div class="breadcrumb-style">
                        <?php albakers_breadcrumbs(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- AlBaker World Blog Start Here -->
    <section class="blog-page">
        <!-- Filters Start Here -->
        <div class="filters">
            <div class="container">
                <div class="row">
                    <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6 col-12">
                        <div class="custom-select prods">
                            <select id="prods">
                                <option hidden ><?php _e( 'Products', 'albaker_ts' ); ?></option>   
                            
                        <?php query_posts(array(
                            'post_type' => 'products',
                            'posts_per_page' => -1,
                            'order' => 'desc'
                                    
                                )); 
                                if (have_posts()) :  while (have_posts()) : the_post(); ?>
	
	                <option value="<?php echo $post->ID ?>">      <?php the_title()?> </option>
	
                    <?php endwhile; wp_reset_query(); else : ?>
                        <h2><?php _e('Nothing Found','albaker_ts'); ?></h2>
                        <?php endif; ?> 

                            </select>
                        </div>
                    </div>
                    <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6 col-12">
                    <div class="custom-select cates">
                    <?php
                                
                                $tex_categories = get_terms( array('taxonomy' => 'categories','hide_empty' => false ) );                                            
                                            if ( !empty($tex_categories) ) :
                                                $output = '<select id="cates">';                                              
                                                $output.= '<option hidden >'.__( 'Courses', 'albaker_ts' ) .'</option>';
                                                foreach( $tex_categories as $tex_categorie ) {
                                                      $output.= '<option value="'. esc_attr( $tex_categorie->slug ) .'">'. esc_html( $tex_categorie->name ) .'</option>';
                                                     }
                                                $output.='</select>';
                                                echo $output;
                                            endif;

                                            ?>
                        </div>
                    </div>
                    <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6 col-12">
                        <div class="custom-select tags">
                        <?php
                                
                                $tex_recipe_tags = get_terms( array('taxonomy' => 'cuisine','hide_empty' => false ) );
                                            
                                            if ( !empty($tex_recipe_tags) ) :
                                                $output = '<select id="tags">';
                                                $output.= '<option hidden >'.__( 'Cuisine', 'albaker_ts' ) .'</option>';
                                                foreach( $tex_recipe_tags as $tex_recipe_tag ) {
                                                    $output.= '<option value="'. esc_attr( $tex_recipe_tag->slug ) .'">'. esc_html( $tex_recipe_tag->name ) .'</option>';

                                                }
                                                $output.='</select>';
                                                echo $output;
                                            endif;

                                            ?>
                        </div>
                    </div>
                    <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6 col-12">
                        <div class="custom-select occasion">
                          
                          <?php  $tex_occasions = get_terms( array('taxonomy' => 'occasions','hide_empty' => false ) );
                                            
                                 if ( !empty($tex_occasions) ) :
                                                $output = '<select id="filters_occasion">';                                               
                                                $output.= '<option hidden >'.__( 'Occasions', 'albaker_ts' ) .'</option>';
                                                foreach( $tex_occasions as $tex_occasion ) {
                                                    $output.= '<option value="'. esc_attr( $tex_occasion->slug ) .'">
                                                    '. esc_html( $tex_occasion->name ) .'</option>';

                                                }
                                                $output.='</select>';
                                                echo $output;
                                   endif;

                                            ?>




                        
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Sorting Start Here -->
        <div class="sorting-area">
            <div class="container">
                <div class="row">
                    <div class="col-xl-9 col-lg-8 col-md-7 col-sm-12 col-12 my-auto">
                        <div class="result"> <?php _e( 'We have found', 'albaker_ts' ); ?><?php  $count_articles = wp_count_posts( $post_type = 'recipes' );
                        echo "<span>".$count_articles->publish . "</span>";     ?> <?php _e( 'results fitting your needs', 'albaker_ts' ); ?>
                        </div>
                    </div>
                    <div class="col-xl-3 col-lg-4 col-md-5 col-sm-4 col-12">
                        <div class="custom-select orderfilters">
                            <select id="filters">
                                <option hidden ><?php _e( 'SORT BY ', 'albaker_ts' ); ?></option>
                                <option value="ASC"><?php _e( 'LATEST ADDED RECIPES', 'albaker_ts' ); ?></option>
                                <option value="DESC"><?php _e( 'MOST VIEWED RECIPES', 'albaker_ts' ); ?></option>
                            </select>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- listing Start Here -->
        <div class="blog-grid">
            <div class="container">


         <div class="row load_post ">              
          </div>                   

        <div class="row nonajax load-more-target posts_list">

        <?php query_posts(array(
            'post_type' => 'recipes',
            'posts_per_page' => -1,
			'order' => 'desc'
			
        )); 
        if (have_posts()) :  while (have_posts()) : the_post(); 
         get_template_part('template-part/recipes','layout');
         
         endwhile; wp_reset_query();  else : ?>
			<h2><?php _e('Nothing Found','albaker_ts'); ?></h2>
	        <?php endif; ?>    
                </div>


             

            </div>
        </div>
       
    </section>
     <!-- Signup Section Start Here -->
     <?php get_template_part('inc/newletter'); ?>
     <!-- End Signup Section Start Here -->
   
 
<?php get_footer(); ?>

<script type="text/javascript">

$(document).ready(function(){

$(".prods").on("click", function() {



    var prods = $('#prods :selected').val();
   
    jQuery.ajax({
          type:"POST",
          url:"<?php echo admin_url('admin-ajax.php'); ?>",
          data: {
            action: "get_post_by_products",
            cname : prods,		
          },
          success: function(response){
            $( ".nonajax" ).hide();
            $( ".result" ).hide();            
           $( ".load_post" ).html( response );
          }
        });
 

});

$(".tags").on("click", function() {

    var ctags =  $('#tags :selected').val(); 


    $.ajax({
          type:"POST",
          url:"<?php echo admin_url('admin-ajax.php'); ?>",
          data: {
            action: "get_post_by_tags",
            cname : ctags,		
          },
          success: function(response){
            $( ".nonajax" ).hide();
            $( ".result" ).hide();            
           $( ".load_post" ).html( response );
          }
        });

});



// ajax Cates
$(".cates").on("click", function() {		
   

    var cname = $('#cates :selected').val();
    jQuery.ajax({
          type:"POST",
          url:"<?php echo admin_url('admin-ajax.php'); ?>",
          data: {
            action: "get_post_by_cates",
            cname : cname,		
          },
          success: function(response){
            $( ".nonajax" ).hide();
            $( ".result" ).hide();            
           $( ".load_post" ).html( response );
          }
        });
  
    
  });

// ajax occasion
  $(".occasion").on("click", function() {
    
    var occasion = $('#filters_occasion :selected').val();
   jQuery.ajax({
         type:"POST",
         url:"<?php echo admin_url('admin-ajax.php'); ?>",
         data: {
           action: "get_post_by_occasion",
           cname : occasion,		
         },
         success: function(response){
           $( ".nonajax" ).hide();
           $( ".result" ).hide();            
          $( ".load_post" ).html( response );
         }
       });

});


$(".orderfilters").on("click", function() {
    
    var filters = $('#filters :selected').val();
   
   jQuery.ajax({
         type:"POST",
         url:"<?php echo admin_url('admin-ajax.php'); ?>",
         data: {
           action: "get_recepies_by_sorting",
           cname : filters,		
         },
         success: function(response){
           $( ".nonajax" ).hide();
           $( ".result" ).hide();            
          $( ".load_post" ).html( response );
         }
       });

});



});


</script>