<?php get_header(); ?>




<section>
        <div class="page-main-area" style="background: url(<?php bloginfo('template_directory'); ?>/images/blur-banner-bar.png) bottom center no-repeat , url(<?php bloginfo('template_directory'); ?>/images/contact-banner.jpg) top center no-repeat;">
            <div class="container">
                <div class="row">
                    <div class="col">
                        <div class="main-title"><?php the_title()?></div>
                        <div class="breadcrumb-style">
                        <?php albakers_breadcrumbs(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>



    <section class="page-body">
        <div class="container">
            <div class="row">

<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
    <div class="post" id="post-<?php the_ID(); ?>">
     		<?php the_content(); ?>			
    </div>
<?php endwhile; endif; ?>
</div></div>
</section>


<?php get_footer(); ?>