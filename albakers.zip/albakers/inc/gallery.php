
               
                        <div id="myCarousel" class="carousel slide myCarousel" data-ride="carousel">
                            <div class="carousel-inner">
                               
                                  

                                <?php if( have_rows('gallery') ): ?>
                                  
                                        <?php
                                        $i = 0 ;
                                        while( have_rows('gallery') ): the_row(); 
                                        $i++;
                                            $image = get_sub_field('image');
                                            $type = get_sub_field('type');
                                            $video = get_sub_field('video');
                                            

                                           
                                            ?>

                               <?php if($type == 'Image') { ?>

                                          <div class="carousel-item <?php if ($i == 1) { echo "active";} ?> ">
                                            <img  src="<?php echo $image ?> " class="zoomit d-block w-100">                                   
                                            <div class="zoom">
                                                <img src="<?php bloginfo('template_directory'); ?>/images/plus.png" class="zoom-in">
                                                <img src="<?php bloginfo('template_directory'); ?>/images/minus.png" class="zoom-out">
                                            </div>
                                          </div>
                                            <?php } else {  ?>

                                        <div class="carousel-item <?php if ($i == 1) { echo "active";} ?> "> 
                                                <div class="embed-responsive embed-responsive-16by9" style="min-height:466px;">
	       							            	<iframe class="embed-responsive-item" src="https://www.youtube.com/embed/<?php echo $video ?>" allowfullscreen  ></iframe>
	       						                </div> 
                                        </div> 
                                    <?php  }  ?>
                                        





                                        <?php endwhile; ?>
                                 
                                    <?php endif; ?>





                     
                            </div>
                        </div>
                        <!-- Carousel Navigation -->
                        <div id="carousel-thumbs" class="carousel carousel-thumbs">
                            <div class="carousel-inner">
                                

                                <?php if( have_rows('gallery') ): ?>
                              
                                <?php
                                $count = 0 ;
                                while( have_rows('gallery') ): the_row();
                                
                                $image = get_sub_field('image');
                                $type = get_sub_field('type');
                                $video = get_sub_field('video');

                               // echo $video;
                                
                                ?>

                                
                            
                          
                        <?php
                            if($count % 3 == 0): ?>
                               <div class="carousel-item <?php if($count == 0) { echo "active";}?> ">
                               <div class="carousel-thumbs-row">
                               <?php endif ?>

                         


                                    <?php if($type == 'Image') { ?>

                                        <div class="thumb <?php if($count == 0) { echo "selected";}?>" data-target="#myCarousel" data-slide-to="<?php echo $count ?>">
                                             <img src="<?php echo $image ?>"  class="img-fluid">  

                                          </div>
                                           
                                            
                                            <?php } else {  ?>

                                                <div class="thumb <?php if($count == 0) { echo "selected";}?>" data-target="#myCarousel" data-slide-to="<?php echo $count ?>">

                                            <img src="https://i.ytimg.com/vi/<?php echo $video ?>/0.jpg"  class="img-fluid">  
                                            </div>



                                          <?php  }  ?>

                                           




                            


                               




                              

                            <?php 
                            // if the result of the modulo operation is 2, close row
                            if($count % 3 == 2): ?>
                                </div>
                                </div>
                            <?php endif ?>
                                    

                                <?php $count++;   endwhile; ?>

                            
                            <?php endif; ?>
                            
                              <a class="carousel-control-prev" href="#carousel-thumbs" role="button" data-slide="prev">
                                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                    <span class="sr-only">Previous</span>
                                </a>
                                <a class="carousel-control-next" href="#carousel-thumbs" role="button" data-slide="next">
                                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                    <span class="sr-only">Next</span>
                                </a>
                            </div>
                            </div>
                            </div>
                            </div>
                        

                    
           