<form action="<?php bloginfo('siteurl'); ?>" id="searchform" method="get">
    <div id="search-top">
        <input type="text" id="s" class="search-input" name="s" value="" /><input type="submit" class="search-button" value="<?php _e("Search", "text_domain"); ?>" id="searchsubmit" />
    </div>
</form>