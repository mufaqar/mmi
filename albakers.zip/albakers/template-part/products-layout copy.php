<div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 col-12">
                        <div class="single-product">
                                                <div class="product-image">
                                                    <a href="<?php echo get_permalink( $post_7 ); ?>">                            
                                                
                                                <?php if (has_post_thumbnail( $post_7 ) ): ?>
                    <?php $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post_7 ), 'product-thumbnail' ); ?>
                    <img src="<?php echo $image ?>" alt="Featured Thumbnail" />

                    </div>
                    <?php endif; ?>





                            </a>
                            </div>
                            <div class="single-product-body">
                                <a href="<?php the_permalink()?>">
                                    <div class="product-title"><?php echo $title ?></div>
                                </a>
                            </div>
                        </div>
                    </div>