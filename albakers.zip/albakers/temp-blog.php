<?php
 /*  Template Name:  Blog */

get_header(); ?>

<section>
        <div class="page-main-area" style="background: url(<?php bloginfo('template_directory'); ?>/images/blur-banner-bar.png) bottom center no-repeat , url(<?php bloginfo('template_directory'); ?>/images/contact-banner.jpg) top center no-repeat;">
            <div class="container">
                <div class="row">
                    <div class="col">
                        <div class="main-title"><?php the_title()?></div>
                        <div class="breadcrumb-style">
                        <?php albakers_breadcrumbs(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
  <!-- News Start Here -->
  <section class="blog-grid" style="margin-bottom:60px;">
        <div class="container">
            
            <div class="row blog-posts posts_list">
             <?php
                    $args = array(
                        'post_type' => 'post',
                        'post_status' => 'publish',
                        'posts_per_page' => '-1',
                        'paged' => 1,
                    );
                    $blog_posts = new WP_Query( $args );    ?>

            <?php if ( $blog_posts->have_posts() ) : ?>
              
               
                <?php while ( $blog_posts->have_posts() ) : $blog_posts->the_post(); ?>   

                         <?php get_template_part('template-part/blog','layout');?> 

                <?php endwhile; ?>
                        
                        
       
                          
          <?php endif; ?>
              
     
            </div>           
        </div>

       
    </section>
     <!-- Signup Section Start Here -->
     <?php get_template_part('inc/newletter'); ?>
     <!-- End Signup Section Start Here -->
 

<?php get_footer(); ?>